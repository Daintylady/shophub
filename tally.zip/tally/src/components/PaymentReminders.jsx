// PaymentReminders.jsx
// Drop this component into Dashboard.jsx
// Shows credits due in the next 3 days with one-tap WhatsApp reminder buttons
// Pro feature only

import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { usePro } from '../lib/usePro'

function PaymentReminders() {
  const { isPro } = usePro()
  const [upcoming, setUpcoming] = useState([])
  const [shopName, setShopName] = useState('')
  const [sent, setSent] = useState([])
  const [loading, setLoading] = useState(true)
  const [collapsed, setCollapsed] = useState(false)

  useEffect(() => {
    if (isPro) loadReminders()
    else setLoading(false)
  }, [isPro])

  const loadReminders = async () => {
    const { data: userData } = await supabase.auth.getUser()
    setShopName(userData.user?.user_metadata?.shop_name || 'Our Shop')

    const today = new Date()
    const todayStr = today.toISOString().split('T')[0]

    // 3 days from now
    const in3Days = new Date()
    in3Days.setDate(in3Days.getDate() + 3)
    const in3DaysStr = in3Days.toISOString().split('T')[0]

    // Credits due between today and 3 days from now (unpaid only)
    const { data } = await supabase
      .from('credits')
      .select('*, customers(id, full_name, phone)')
      .eq('status', 'unpaid')
      .gte('due_date', todayStr)
      .lte('due_date', in3DaysStr)
      .order('due_date', { ascending: true })

    setUpcoming(data || [])
    setLoading(false)
  }

  const sendReminder = (credit) => {
    const phone = credit.customers?.phone
      ? credit.customers.phone.replace(/^0/, '234')
      : null
    if (!phone) return

    const balance = credit.amount - credit.amount_paid
    const daysLeft = Math.ceil(
      (new Date(credit.due_date) - new Date()) / (1000 * 60 * 60 * 24)
    )

    const message =
      `Hello ${credit.customers.full_name}! 👋 This is a friendly reminder from *${shopName}*.\n\n` +
      `You have an outstanding balance of *₦${balance.toLocaleString()}* due ` +
      (daysLeft === 0
        ? '*today*'
        : daysLeft === 1
        ? '*tomorrow*'
        : `in *${daysLeft} days* (${credit.due_date})`) +
      `.\n\nPlease make payment at your earliest convenience. Thank you! 🙏`

    window.open(
      `https://wa.me/${phone}?text=${encodeURIComponent(message)}`,
      '_blank'
    )
    setSent(prev => [...prev, credit.id])
  }

  const sendAll = () => {
    upcoming.forEach((credit, i) => {
      if (sent.includes(credit.id)) return
      setTimeout(() => sendReminder(credit), i * 900)
    })
  }

  // Don't render anything if not Pro or no upcoming credits
  if (!isPro || loading) return null
  if (upcoming.length === 0) return null

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header} onClick={() => setCollapsed(!collapsed)}>
        <div style={styles.headerLeft}>
          <div style={styles.dot} />
          <p style={styles.title}>
            ⏰ {upcoming.length} payment{upcoming.length > 1 ? 's' : ''} due soon
          </p>
        </div>
        <div style={styles.headerRight}>
          {!collapsed && upcoming.length > 1 && (
            <button
              onClick={(e) => { e.stopPropagation(); sendAll() }}
              style={styles.sendAllBtn}
            >
              📲 Remind All
            </button>
          )}
          <span style={styles.chevron}>{collapsed ? '▼' : '▲'}</span>
        </div>
      </div>

      {/* Credit rows */}
      {!collapsed && (
        <div style={styles.list}>
          {upcoming.map(credit => {
            const balance = credit.amount - credit.amount_paid
            const daysLeft = Math.ceil(
              (new Date(credit.due_date) - new Date()) / (1000 * 60 * 60 * 24)
            )
            const isSent = sent.includes(credit.id)
            const hasPhone = !!credit.customers?.phone

            const urgencyColor =
              daysLeft === 0 ? '#e53e3e' :
              daysLeft === 1 ? '#d97706' :
              '#38a169'

            const urgencyLabel =
              daysLeft === 0 ? 'Due today' :
              daysLeft === 1 ? 'Due tomorrow' :
              `Due in ${daysLeft} days`

            return (
              <div key={credit.id} style={styles.row}>
                <div style={styles.rowInfo}>
                  <p style={styles.customerName}>
                    {credit.customers?.full_name || 'Unknown'}
                  </p>
                  <div style={styles.rowMeta}>
                    <span
                      style={{
                        ...styles.urgencyBadge,
                        backgroundColor: urgencyColor + '18',
                        color: urgencyColor,
                      }}
                    >
                      {urgencyLabel}
                    </span>
                    <span style={styles.balanceText}>
                      ₦{balance.toLocaleString()}
                    </span>
                  </div>
                  {!hasPhone && (
                    <p style={styles.noPhone}>No phone number saved</p>
                  )}
                </div>

                <button
                  onClick={() => sendReminder(credit)}
                  disabled={!hasPhone || isSent}
                  style={
                    isSent ? styles.sentBtn :
                    !hasPhone ? styles.disabledBtn :
                    styles.remindBtn
                  }
                >
                  {isSent ? '✓ Sent' : '📲'}
                </button>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

const styles = {
  container: {
    backgroundColor: '#fffbeb',
    border: '1.5px solid #f59e0b',
    borderRadius: '16px',
    padding: '16px',
    marginBottom: '20px',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    cursor: 'pointer',
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  dot: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    backgroundColor: '#f59e0b',
    flexShrink: 0,
  },
  title: {
    fontSize: '14px',
    fontWeight: '700',
    color: '#92400e',
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  sendAllBtn: {
    padding: '6px 14px',
    backgroundColor: '#25D366',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    fontSize: '12px',
    fontWeight: '700',
    cursor: 'pointer',
  },
  chevron: {
    fontSize: '12px',
    color: '#92400e',
  },
  list: {
    marginTop: '12px',
    display: 'flex',
    flexDirection: 'column',
    gap: '0px',
  },
  row: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 0',
    borderTop: '1px solid #fde68a',
  },
  rowInfo: {
    flex: 1,
  },
  customerName: {
    fontSize: '14px',
    fontWeight: '700',
    color: '#1a1a2e',
    marginBottom: '4px',
  },
  rowMeta: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  urgencyBadge: {
    fontSize: '11px',
    fontWeight: '700',
    padding: '3px 8px',
    borderRadius: '20px',
  },
  balanceText: {
    fontSize: '13px',
    fontWeight: '700',
    color: '#1a1a2e',
  },
  noPhone: {
    fontSize: '11px',
    color: '#aaa',
    marginTop: '3px',
  },
  remindBtn: {
    padding: '8px 14px',
    backgroundColor: '#25D366',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    cursor: 'pointer',
    flexShrink: 0,
  },
  sentBtn: {
    padding: '8px 14px',
    backgroundColor: '#e0e0e0',
    color: '#888',
    border: 'none',
    borderRadius: '8px',
    fontSize: '12px',
    fontWeight: '700',
    cursor: 'default',
    flexShrink: 0,
  },
  disabledBtn: {
    padding: '8px 14px',
    backgroundColor: '#f0f0f0',
    color: '#ccc',
    border: 'none',
    borderRadius: '8px',
    fontSize: '12px',
    fontWeight: '700',
    cursor: 'not-allowed',
    flexShrink: 0,
  },
}

export default PaymentReminders
