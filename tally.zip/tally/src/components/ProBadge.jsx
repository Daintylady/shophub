// ProBadge.jsx
// Drop this into any page header next to the title.
// Shows 👑 PRO (gold) if subscribed, or 👑 with a red dot if free.
// Tapping it opens the ProUpgrade sheet.

import { useState } from 'react'
import { usePro } from '../lib/usePro'
import ProUpgrade from '../pages/ProUpgrade'

function ProBadge({ source = 'manual' }) {
  const { isPro, loading } = usePro()
  const [showUpgrade, setShowUpgrade] = useState(false)

  if (loading) return null

  return (
    <>
      <button
        onClick={() => !isPro && setShowUpgrade(true)}
        style={isPro ? styles.proBadge : styles.freeBadge}
        title={isPro ? 'Tally Pro — Active' : 'Upgrade to Pro'}
      >
        👑
        {!isPro && <span style={styles.dot} />}
        <span style={styles.label}>{isPro ? 'PRO' : 'Free'}</span>
      </button>

      {showUpgrade && (
        <ProUpgrade
          source={source}
          onClose={() => setShowUpgrade(false)}
        />
      )}
    </>
  )
}

const styles = {
  proBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    padding: '6px 12px',
    backgroundColor: '#fef3c7',
    border: '1.5px solid #f59e0b',
    borderRadius: '20px',
    fontSize: '13px',
    fontWeight: '700',
    cursor: 'default',
    color: '#92400e',
    position: 'relative',
  },
  freeBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    padding: '6px 12px',
    backgroundColor: '#f0f4f8',
    border: '1.5px solid #e0e0e0',
    borderRadius: '20px',
    fontSize: '13px',
    fontWeight: '700',
    cursor: 'pointer',
    color: '#888',
    position: 'relative',
  },
  dot: {
    width: '7px',
    height: '7px',
    backgroundColor: '#e53e3e',
    borderRadius: '50%',
    position: 'absolute',
    top: '4px',
    right: '4px',
  },
  label: { fontSize: '11px', fontWeight: '700' },
}

export default ProBadge
