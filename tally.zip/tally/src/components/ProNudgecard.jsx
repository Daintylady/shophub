// ProNudgeCard.jsx
// Shown once inside the customer list — subtle purple card, same visual
// weight as a customer row. Tapping opens the ProUpgrade sheet.
// Only renders for free users. Pass `trigger` to control when it appears:
//   'always'   — always show (for demo/testing)
//   'halfway'  — show after 250 customers (halfway to 500 limit)
//   'invoice'  — show after 2 invoices used (1 remaining)

import { useState } from 'react'
import { usePro } from '../lib/usePro'
import ProUpgrade from '../pages/ProUpgrade'

function ProNudgeCard({ trigger = 'always' }) {
  const { isPro, customerCount, invoicesRemaining, loading } = usePro()
  const [showUpgrade, setShowUpgrade] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  if (loading || isPro || dismissed) return null

  // Decide whether to show based on trigger
  if (trigger === 'halfway' && customerCount < 250) return null
  if (trigger === 'invoice' && invoicesRemaining > 1) return null

  const isInvoiceTrigger = trigger === 'invoice'

  return (
    <>
      <div style={styles.card}>
        <button
          onClick={() => setDismissed(true)}
          style={styles.dismissBtn}
        >
          ✕
        </button>

        <div style={styles.topRow}>
          <span style={styles.crown}>👑</span>
          <div>
            <p style={styles.title}>
              {isInvoiceTrigger
                ? `${invoicesRemaining} free invoice${invoicesRemaining !== 1 ? 's' : ''} left`
                : 'Unlock Tally Pro'}
            </p>
            <p style={styles.sub}>
              {isInvoiceTrigger
                ? 'Upgrade for unlimited invoices, analytics, expense tracking and more.'
                : 'Analytics, invoices, expenses, auto-reminders and more — ₦5,000/month.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowUpgrade(true)}
          style={styles.upgradeBtn}
        >
          See Pro Features →
        </button>
      </div>

      {showUpgrade && (
        <ProUpgrade
          source={isInvoiceTrigger ? 'invoice_limit' : 'manual'}
          onClose={() => setShowUpgrade(false)}
        />
      )}
    </>
  )
}

const styles = {
  card: {
    backgroundColor: '#1a1a2e',
    borderRadius: '14px',
    padding: '16px',
    marginBottom: '10px',
    position: 'relative',
  },
  dismissBtn: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    background: 'rgba(255,255,255,0.1)',
    border: 'none',
    borderRadius: '50%',
    width: '24px',
    height: '24px',
    color: '#aaa',
    fontSize: '12px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topRow: {
    display: 'flex',
    gap: '12px',
    alignItems: 'flex-start',
    marginBottom: '14px',
  },
  crown: { fontSize: '24px', flexShrink: 0 },
  title: { fontSize: '15px', fontWeight: '700', color: '#ffffff', marginBottom: '4px' },
  sub: { fontSize: '12px', color: '#888', lineHeight: '1.5' },
  upgradeBtn: {
    width: '100%',
    padding: '11px',
    backgroundColor: '#fef3c7',
    color: '#92400e',
    border: 'none',
    borderRadius: '10px',
    fontSize: '14px',
    fontWeight: '700',
    cursor: 'pointer',
  },
}

export default ProNudgeCard
