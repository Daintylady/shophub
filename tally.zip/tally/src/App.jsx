import { Routes, Route } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Customers from './pages/Customers'
import AddCustomer from './pages/AddCustomer'
import AddCredit from './pages/AddCredit'
import Analytics from './pages/Analytics'
import Broadcast from './pages/Broadcast'
import Invoice from './pages/Invoice'
import ProUpgrade from './pages/ProUpgrade'
import ProSuccess from './pages/ProSuccess'
import Expenses from './pages/Expenses'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/customers" element={<Customers />} />
      <Route path="/add-customer" element={<AddCustomer />} />
      <Route path="/add-credit" element={<AddCredit />} />
      <Route path="/analytics" element={<Analytics />} />
      <Route path="/broadcast" element={<Broadcast />} />
      <Route path="/invoice" element={<Invoice />} />
      <Route path="/expenses" element={<Expenses />} />
      <Route path="/pro" element={<ProUpgrade onClose={() => window.history.back()} source="manual" />} />
      <Route path="/pro-success" element={<ProSuccess />} />
    </Routes>
  )
}

export default App
