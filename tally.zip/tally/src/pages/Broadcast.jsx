import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Link } from 'react-router-dom'

// ─── Modes ───────────────────────────────────────────────
// 'arrivals'  → New Arrivals: list items, auto-match wishlist customers
// 'search'    → Single product search (original behaviour, improved)
// 'general'   → Broadcast to everyone

function Broadcast() {
  const [mode, setMode] = useState('arrivals')
  const [allCustomers, setAllCustomers] = useState([])
  const [shopName, setShopName] = useState('')
  const [loading, setLoading] = useState(true)

  // ── New Arrivals state ──
  const [arrivalInput, setArrivalInput] = useState('')
  const [arrivalItems, setArrivalItems] = useState([])
  const [arrivalMatches, setArrivalMatches] = useState([]) // [{customer, wantedItems[]}]
  const [arrivalMessage, setArrivalMessage] = useState('')
  const [arrivalSent, setArrivalSent] = useState([])
  const [arrivalSearched, setArrivalSearched] = useState(false)

  // ── Single search state ──
  const [product, setProduct] = useState('')
  const [searchMatches, setSearchMatches] = useState([])
  const [searchMessage, setSearchMessage] = useState('')
  const [searchSent, setSearchSent] = useState([])
  const [searched, setSearched] = useState(false)

  // ── General broadcast state ──
  const [generalMessage, setGeneralMessage] = useState('')
  const [generalSent, setGeneralSent] = useState([])
  const [generalStarted, setGeneralStarted] = useState(false)

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    const { data: userData } = await supabase.auth.getUser()
    const name = userData.user?.user_metadata?.shop_name || 'Our Shop'
    setShopName(name)

    const { data } = await supabase
      .from('customers')
      .select('id, full_name, phone, wishlist')
      .order('full_name')
    setAllCustomers(data || [])
    setLoading(false)

    // default general message
    setGeneralMessage(
      `Hello! This is ${name}. We have exciting new arrivals in store — come in today or message us to reserve yours! 🛍️`
    )
  }

  // ─────────────────────────────────────────────
  // NEW ARRIVALS HELPERS
  // ─────────────────────────────────────────────
  const addArrivalItem = () => {
    const trimmed = arrivalInput.trim()
    if (!trimmed) return
    if (!arrivalItems.includes(trimmed.toLowerCase())) {
      setArrivalItems(prev => [...prev, trimmed.toLowerCase()])
    }
    setArrivalInput('')
  }

  const removeArrivalItem = (item) => {
    setArrivalItems(prev => prev.filter(i => i !== item))
    setArrivalSearched(false)
  }

  const findArrivalMatches = () => {
    if (arrivalItems.length === 0) return
    const results = []
    allCustomers.forEach(c => {
      if (!c.wishlist) return
      const wl = c.wishlist.toLowerCase()
      const wanted = arrivalItems.filter(item => wl.includes(item))
      if (wanted.length > 0) results.push({ customer: c, wantedItems: wanted })
    })
    // Sort: most matches first
    results.sort((a, b) => b.wantedItems.length - a.wantedItems.length)
    setArrivalMatches(results)
    setArrivalSearched(true)

    // Build message with full item list
    const itemList = arrivalItems.map(i => `• ${i}`).join('\n')
    setArrivalMessage(
      `Hello! 🎉 Great news from *${shopName}*!\n\nWe have new arrivals:\n${itemList}\n\nCome in today or send us a message to reserve yours before they sell out!`
    )
  }

  const sendArrival = (customer, personalMessage) => {
    if (!customer.phone) return
    const phone = customer.phone.replace(/^0/, '234')
    // Personalised: mention which items this customer specifically wanted
    const theirItems = arrivalMatches.find(m => m.customer.id === customer.id)?.wantedItems || []
    const personal = theirItems.length > 0
      ? `Hello ${customer.full_name}! 🎉 You're in luck — *${shopName}* now has *${theirItems.join(', ')}* in stock! Come in or message us to reserve yours.\n\n${personalMessage}`
      : `Hello ${customer.full_name}, ${personalMessage}`
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(personal)}`, '_blank')
    setArrivalSent(prev => [...prev, customer.id])
  }

  const sendAllArrivals = () => {
    arrivalMatches.forEach(({ customer }, i) => {
      setTimeout(() => sendArrival(customer, arrivalMessage), i * 900)
    })
  }

  // ─────────────────────────────────────────────
  // SINGLE SEARCH HELPERS
  // ─────────────────────────────────────────────
  const handleSearch = () => {
    if (!product.trim()) return
    const kw = product.trim().toLowerCase()
    const found = allCustomers.filter(c => c.wishlist && c.wishlist.toLowerCase().includes(kw))
    setSearchMatches(found)
    setSearched(true)
    setSearchMessage(
      `Hello! This is *${shopName}* 🎉 Great news — *${product}* is now available. Come in or contact us to reserve yours before it sells out!`
    )
  }

  const sendSearchOne = (c) => {
    if (!c.phone) return
    const phone = c.phone.replace(/^0/, '234')
    const text = `Hello ${c.full_name}, ${searchMessage}`
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank')
    setSearchSent(prev => [...prev, c.id])
  }

  const sendSearchAll = () => {
    searchMatches.forEach((c, i) => {
      setTimeout(() => sendSearchOne(c), i * 900)
    })
  }

  // ─────────────────────────────────────────────
  // GENERAL BROADCAST HELPERS
  // ─────────────────────────────────────────────
  const sendGeneral = () => {
    setGeneralStarted(true)
    allCustomers.forEach((c, i) => {
      if (!c.phone) return
      const phone = c.phone.replace(/^0/, '234')
      const text = `Hello ${c.full_name}, ${generalMessage}`
      setTimeout(() => {
        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank')
        setGeneralSent(prev => [...prev, c.id])
      }, i * 900)
    })
  }

  // ─────────────────────────────────────────────
  // How many customers match each item (for badge count)
  // ─────────────────────────────────────────────
  const countMatches = (item) =>
    allCustomers.filter(c => c.wishlist && c.wishlist.toLowerCase().includes(item)).length

  if (loading) return <div style={styles.loading}>Loading...</div>

  return (
    <div style={styles.container}>

      {/* ── Header ── */}
      <div style={styles.header}>
         <Link to="/dashboard" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title}>📢 Broadcast</h2>
        <div />
      </div>

      {/* ── Mode Tabs ── */}
      <div style={styles.tabs}>
        {[
          { key: 'arrivals', label: '🆕 New Arrivals' },
          { key: 'search',   label: '🔍 Find by Want' },
          { key: 'general',  label: '📣 Everyone' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setMode(tab.key)}
            style={mode === tab.key ? styles.tabActive : styles.tab}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ══════════════════════════════════════
          MODE 1 — NEW ARRIVALS
      ══════════════════════════════════════ */}
      {mode === 'arrivals' && (
        <>
          <div style={styles.section}>
            <p style={styles.sectionTitle}>What just arrived?</p>
            <p style={styles.hint}>
              Add each new item. We'll find every customer whose wishlist includes it.
            </p>

            {/* Item entry */}
            <div style={styles.rowGap}>
              <input
                type="text"
                value={arrivalInput}
                onChange={e => setArrivalInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addArrivalItem()}
                placeholder="e.g. red handbag"
                style={styles.input}
              />
              <button onClick={addArrivalItem} style={styles.addItemBtn}>Add</button>
            </div>

            {/* Item chips with match count */}
            {arrivalItems.length > 0 && (
              <div style={styles.chipRow}>
                {arrivalItems.map(item => {
                  const count = countMatches(item)
                  return (
                    <div key={item} style={styles.chip}>
                      <span style={styles.chipText}>{item}</span>
                      {count > 0 && (
                        <span style={styles.chipBadge}>{count} want this</span>
                      )}
                      <button
                        onClick={() => removeArrivalItem(item)}
                        style={styles.chipX}
                      >×</button>
                    </div>
                  )
                })}
              </div>
            )}

            {arrivalItems.length > 0 && (
              <button onClick={findArrivalMatches} style={styles.primaryBtn}>
                🔍 Find Matching Customers
              </button>
            )}
          </div>

          {/* Message editor */}
          {arrivalSearched && (
            <div style={styles.section}>
              <p style={styles.sectionTitle}>Your message</p>
              <p style={styles.hint}>
                Targeted customers get a personalised version mentioning their specific item.
              </p>
              <textarea
                value={arrivalMessage}
                onChange={e => setArrivalMessage(e.target.value)}
                style={styles.textarea}
                rows={5}
              />
            </div>
          )}

          {/* Results */}
          {arrivalSearched && (
            <div style={styles.section}>
              <div style={styles.resultsHeader}>
                <p style={styles.sectionTitle}>
                  {arrivalMatches.length > 0
                    ? `${arrivalMatches.length} customer${arrivalMatches.length > 1 ? 's' : ''} matched`
                    : 'No wishlist matches'}
                </p>
                {arrivalMatches.length > 0 && (
                  <button onClick={sendAllArrivals} style={styles.sendAllBtn}>
                    📲 Send All
                  </button>
                )}
              </div>

              {arrivalMatches.length === 0 ? (
                <p style={styles.emptyHint}>
                  None of your customers have these items in their wishlist yet. Use "Everyone" tab to broadcast generally.
                </p>
              ) : (
                arrivalMatches.map(({ customer, wantedItems }) => (
                  <div key={customer.id} style={styles.customerRow}>
                    <div style={styles.avatar}>
                      {customer.full_name.charAt(0).toUpperCase()}
                    </div>
                    <div style={styles.info}>
                      <p style={styles.name}>{customer.full_name}</p>
                      <p style={styles.phone}>{customer.phone || 'No phone'}</p>
                      <div style={styles.wantedChips}>
                        {wantedItems.map(w => (
                          <span key={w} style={styles.wantedChip}>🛍️ {w}</span>
                        ))}
                      </div>
                    </div>
                    <button
                      onClick={() => sendArrival(customer, arrivalMessage)}
                      style={arrivalSent.includes(customer.id) ? styles.sentBtn : styles.sendBtn}
                    >
                      {arrivalSent.includes(customer.id) ? '✓ Sent' : '📲'}
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}

      {/* ══════════════════════════════════════
          MODE 2 — SINGLE PRODUCT SEARCH
      ══════════════════════════════════════ */}
      {mode === 'search' && (
        <>
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Search by product</p>
            <p style={styles.hint}>Find every customer who put this item on their wishlist.</p>
            <div style={styles.rowGap}>
              <input
                type="text"
                value={product}
                onChange={e => setProduct(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSearch()}
                placeholder="e.g. ankara fabric"
                style={styles.input}
              />
              <button onClick={handleSearch} style={styles.addItemBtn}>Find</button>
            </div>
          </div>

          {searched && (
            <div style={styles.section}>
              <p style={styles.sectionTitle}>Message</p>
              <textarea
                value={searchMessage}
                onChange={e => setSearchMessage(e.target.value)}
                style={styles.textarea}
                rows={4}
              />
            </div>
          )}

          {searched && (
            <div style={styles.section}>
              <div style={styles.resultsHeader}>
                <p style={styles.sectionTitle}>
                  {searchMatches.length > 0
                    ? `${searchMatches.length} customer${searchMatches.length > 1 ? 's' : ''} want "${product}"`
                    : `No matches for "${product}"`}
                </p>
                {searchMatches.length > 0 && (
                  <button onClick={sendSearchAll} style={styles.sendAllBtn}>
                    📲 Send All
                  </button>
                )}
              </div>

              {searchMatches.length === 0 ? (
                <p style={styles.emptyHint}>
                  No one has "{product}" in their wishlist. Switch to Everyone tab to broadcast to all.
                </p>
              ) : (
                searchMatches.map(c => (
                  <div key={c.id} style={styles.customerRow}>
                    <div style={styles.avatar}>{c.full_name.charAt(0).toUpperCase()}</div>
                    <div style={styles.info}>
                      <p style={styles.name}>{c.full_name}</p>
                      <p style={styles.phone}>{c.phone || 'No phone'}</p>
                      <p style={styles.wishlistText}>🛍️ {c.wishlist}</p>
                    </div>
                    <button
                      onClick={() => sendSearchOne(c)}
                      style={searchSent.includes(c.id) ? styles.sentBtn : styles.sendBtn}
                    >
                      {searchSent.includes(c.id) ? '✓ Sent' : '📲'}
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}

      {/* ══════════════════════════════════════
          MODE 3 — GENERAL BROADCAST
      ══════════════════════════════════════ */}
      {mode === 'general' && (
        <>
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Broadcast to all {allCustomers.length} customers</p>
            <p style={styles.hint}>
              Every customer gets a personalised version with their name. Each opens in WhatsApp one by one.
            </p>
            <textarea
              value={generalMessage}
              onChange={e => setGeneralMessage(e.target.value)}
              style={styles.textarea}
              rows={5}
            />
          </div>

          {/* Progress */}
          {generalStarted && (
            <div style={styles.section}>
              <p style={styles.sectionTitle}>
                Sent: {generalSent.length} / {allCustomers.filter(c => c.phone).length}
              </p>
              <div style={styles.progressBar}>
                <div
                  style={{
                    ...styles.progressFill,
                    width: `${(generalSent.length / Math.max(1, allCustomers.filter(c => c.phone).length)) * 100}%`
                  }}
                />
              </div>
              <p style={styles.hint}>
                WhatsApp opens for each customer automatically. Keep this page open.
              </p>
            </div>
          )}

          <button
            onClick={sendGeneral}
            disabled={generalStarted}
            style={generalStarted ? styles.buttonDisabled : styles.broadcastAllBtn}
          >
            {generalStarted
              ? `Sending... (${generalSent.length}/${allCustomers.filter(c => c.phone).length})`
              : `📢 Send to All ${allCustomers.length} Customers`}
          </button>

          {/* Preview list */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Who will receive this</p>
            {allCustomers.map(c => (
              <div key={c.id} style={styles.customerRow}>
                <div style={styles.avatar}>{c.full_name.charAt(0).toUpperCase()}</div>
                <div style={styles.info}>
                  <p style={styles.name}>{c.full_name}</p>
                  <p style={styles.phone}>{c.phone || 'No phone — will be skipped'}</p>
                  {c.wishlist && <p style={styles.wishlistText}>🛍️ {c.wishlist}</p>}
                </div>
                {generalSent.includes(c.id) && (
                  <span style={styles.sentLabel}>✓ Sent</span>
                )}
              </div>
            ))}
          </div>
        </>
      )}

    </div>
  )
}

const styles = {
  container: {
    maxWidth: '480px',
    margin: '0 auto',
    padding: '20px',
    minHeight: '100vh',
    backgroundColor: '#f0f4f8',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    paddingTop: '10px',
  },
  backBtn: {
    color: '#1a1a2e',
    textDecoration: 'none',
    fontWeight: '600',
    fontSize: '15px',
  },
  title: {
    fontSize: '18px',
    fontWeight: '700',
    color: '#1a1a2e',
  },

  // ── Tabs ──
  tabs: {
    display: 'flex',
    gap: '8px',
    marginBottom: '20px',
  },
  tab: {
    flex: 1,
    padding: '10px 4px',
    backgroundColor: '#ffffff',
    color: '#888',
    border: '1.5px solid #e0e0e0',
    borderRadius: '10px',
    fontSize: '12px',
    fontWeight: '600',
    cursor: 'pointer',
    textAlign: 'center',
  },
  tabActive: {
    flex: 1,
    padding: '10px 4px',
    backgroundColor: '#1a1a2e',
    color: '#ffffff',
    border: '1.5px solid #1a1a2e',
    borderRadius: '10px',
    fontSize: '12px',
    fontWeight: '600',
    cursor: 'pointer',
    textAlign: 'center',
  },

  // ── Section ──
  section: {
    backgroundColor: '#ffffff',
    borderRadius: '16px',
    padding: '20px',
    marginBottom: '16px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  sectionTitle: {
    fontSize: '13px',
    fontWeight: '700',
    color: '#888',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    marginBottom: '10px',
  },
  hint: {
    fontSize: '12px',
    color: '#aaa',
    marginBottom: '12px',
    lineHeight: '1.5',
  },

  // ── Inputs ──
  input: {
    flex: 1,
    padding: '12px 16px',
    borderRadius: '10px',
    border: '1.5px solid #e0e0e0',
    fontSize: '15px',
    outline: 'none',
    backgroundColor: '#fff',
  },
  textarea: {
    width: '100%',
    padding: '12px 16px',
    borderRadius: '10px',
    border: '1.5px solid #e0e0e0',
    fontSize: '14px',
    outline: 'none',
    resize: 'vertical',
    lineHeight: '1.6',
    backgroundColor: '#fff',
    boxSizing: 'border-box',
  },
  rowGap: {
    display: 'flex',
    gap: '10px',
  },
  addItemBtn: {
    padding: '12px 20px',
    backgroundColor: '#1a1a2e',
    color: '#fff',
    border: 'none',
    borderRadius: '10px',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
  },

  // ── Chips ──
  chipRow: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '8px',
    marginTop: '12px',
    marginBottom: '16px',
  },
  chip: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    backgroundColor: '#f0f4f8',
    border: '1.5px solid #1a1a2e',
    borderRadius: '20px',
    padding: '6px 12px',
  },
  chipText: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#1a1a2e',
    textTransform: 'capitalize',
  },
  chipBadge: {
    fontSize: '11px',
    color: '#ffffff',
    backgroundColor: '#38a169',
    borderRadius: '10px',
    padding: '2px 7px',
    fontWeight: '600',
  },
  chipX: {
    background: 'none',
    border: 'none',
    color: '#888',
    fontSize: '16px',
    cursor: 'pointer',
    padding: '0 2px',
    lineHeight: 1,
  },

  // ── Buttons ──
  primaryBtn: {
    width: '100%',
    padding: '14px',
    backgroundColor: '#1a1a2e',
    color: '#fff',
    border: 'none',
    borderRadius: '10px',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
  },
  broadcastAllBtn: {
    width: '100%',
    padding: '16px',
    backgroundColor: '#1a1a2e',
    color: '#fff',
    border: 'none',
    borderRadius: '12px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    marginBottom: '16px',
  },
  buttonDisabled: {
    width: '100%',
    padding: '16px',
    backgroundColor: '#888',
    color: '#fff',
    border: 'none',
    borderRadius: '12px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'not-allowed',
    marginBottom: '16px',
  },

  // ── Results ──
  resultsHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '12px',
  },
  sendAllBtn: {
    padding: '8px 16px',
    backgroundColor: '#25D366',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    fontSize: '13px',
    fontWeight: '600',
    cursor: 'pointer',
  },
  emptyHint: {
    fontSize: '13px',
    color: '#aaa',
    fontStyle: 'italic',
  },

  // ── Customer row ──
  customerRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px 0',
    borderBottom: '1px solid #f0f0f0',
  },
  avatar: {
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    backgroundColor: '#1a1a2e',
    color: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '16px',
    fontWeight: '700',
    flexShrink: 0,
  },
  info: { flex: 1 },
  name: {
    fontWeight: '600',
    fontSize: '14px',
    color: '#1a1a2e',
    marginBottom: '2px',
  },
  phone: {
    fontSize: '12px',
    color: '#888',
  },
  wishlistText: {
    fontSize: '12px',
    color: '#4a90e2',
    marginTop: '2px',
  },
  wantedChips: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '4px',
    marginTop: '4px',
  },
  wantedChip: {
    fontSize: '11px',
    color: '#276749',
    backgroundColor: '#c6f6d5',
    borderRadius: '10px',
    padding: '2px 8px',
    fontWeight: '600',
  },
  sendBtn: {
    padding: '8px 12px',
    backgroundColor: '#25D366',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    fontSize: '18px',
    cursor: 'pointer',
    flexShrink: 0,
  },
  sentBtn: {
    padding: '8px 12px',
    backgroundColor: '#e0e0e0',
    color: '#888',
    border: 'none',
    borderRadius: '8px',
    fontSize: '13px',
    fontWeight: '600',
    cursor: 'default',
    flexShrink: 0,
  },
  sentLabel: {
    fontSize: '12px',
    color: '#38a169',
    fontWeight: '600',
    flexShrink: 0,
  },

  // ── Progress bar ──
  progressBar: {
    height: '8px',
    backgroundColor: '#e0e0e0',
    borderRadius: '4px',
    overflow: 'hidden',
    marginBottom: '10px',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#25D366',
    borderRadius: '4px',
    transition: 'width 0.3s ease',
  },

  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    fontSize: '16px',
    color: '#888',
  },
}

export default Broadcast
