import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { Link } from 'react-router-dom'

const CATEGORIES = [
  { label: 'Rent', icon: '🏠' },
  { label: 'Transport', icon: '🚗' },
  { label: 'Staff Wages', icon: '👷' },
  { label: 'Stock Purchase', icon: '📦' },
  { label: 'Utilities', icon: '💡' },
  { label: 'Marketing', icon: '📣' },
  { label: 'Repairs', icon: '🔧' },
  { label: 'Other', icon: '📝' },
]

function Expenses() {
  const [expenses, setExpenses] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [tab, setTab] = useState('overview') // overview | add | history

  // Form state
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState('Other')
  const [note, setNote] = useState('')
  const [expenseDate, setExpenseDate] = useState(
    new Date().toISOString().split('T')[0]
  )

  // Stats
  const [collectedThisMonth, setCollectedThisMonth] = useState(0)
  const [shopName, setShopName] = useState('')

  useEffect(() => {
    loadAll()
  }, [])

  const loadAll = async () => {
    const { data: userData } = await supabase.auth.getUser()
    setShopName(userData.user?.user_metadata?.shop_name || 'Your Shop')

    // Fetch expenses
    const { data: exp } = await supabase
      .from('expenses')
      .select('*')
      .order('expense_date', { ascending: false })
    setExpenses(exp || [])

    // Fetch payments this month (revenue side)
    const firstOfMonth = new Date(
      new Date().getFullYear(),
      new Date().getMonth(),
      1
    ).toISOString()
    const { data: payments } = await supabase
      .from('payments')
      .select('amount')
      .gte('paid_at', firstOfMonth)
    const collected = (payments || []).reduce((s, p) => s + p.amount, 0)
    setCollectedThisMonth(collected)

    setLoading(false)
  }

  const handleAddExpense = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')

    const { data: userData } = await supabase.auth.getUser()
    const { error: err } = await supabase.from('expenses').insert({
      shop_id: userData.user.id,
      amount: parseFloat(amount),
      category,
      note: note || null,
      expense_date: expenseDate,
    })

    if (err) {
      // Table might not exist yet — show SQL migration message
      if (err.message.includes('expenses')) {
        setError('Run the SQL migration first — see instructions below.')
      } else {
        setError(err.message)
      }
      setSaving(false)
      return
    }

    setAmount('')
    setNote('')
    setCategory('Other')
    setExpenseDate(new Date().toISOString().split('T')[0])
    setSaving(false)
    setTab('overview')
    loadAll()
  }

  const handleDelete = async (id) => {
    await supabase.from('expenses').delete().eq('id', id)
    loadAll()
  }

  // ── Computed stats ──
  const today = new Date()
  const firstOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
    .toISOString()
    .split('T')[0]

  const thisMonthExpenses = expenses.filter(
    e => e.expense_date >= firstOfMonth
  )
  const totalExpensesThisMonth = thisMonthExpenses.reduce(
    (s, e) => s + e.amount,
    0
  )
  const profitThisMonth = collectedThisMonth - totalExpensesThisMonth

  // Group expenses by category for breakdown
  const byCategory = {}
  thisMonthExpenses.forEach(e => {
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount
  })
  const categoryBreakdown = Object.entries(byCategory)
    .map(([cat, total]) => ({ cat, total }))
    .sort((a, b) => b.total - a.total)

  const maxCatTotal = categoryBreakdown[0]?.total || 1

  // Group history by date
  const byDate = {}
  expenses.forEach(e => {
    if (!byDate[e.expense_date]) byDate[e.expense_date] = []
    byDate[e.expense_date].push(e)
  })

  const getCatIcon = (cat) =>
    CATEGORIES.find(c => c.label === cat)?.icon || '📝'

  if (loading) return <div style={styles.loading}>Loading expenses...</div>

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <Link to="/dashboard" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title}>💸 Expenses</h2>
        <div />
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        {[
          { key: 'overview', label: '📊 Overview' },
          { key: 'add', label: '+ Add' },
          { key: 'history', label: '🕐 History' },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={tab === t.key ? styles.tabActive : styles.tab}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ═══════════════════════════════════
          TAB 1 — OVERVIEW
      ═══════════════════════════════════ */}
      {tab === 'overview' && (
        <>
          {/* Profit hero card */}
          <div
            style={{
              ...styles.heroCard,
              backgroundColor: profitThisMonth >= 0 ? '#1a1a2e' : '#7f1d1d',
            }}
          >
            <p style={styles.heroLabel}>
              {today.toLocaleString('default', { month: 'long' })} Profit
            </p>
            <p style={styles.heroAmount}>
              {profitThisMonth >= 0 ? '' : '-'}₦
              {Math.abs(profitThisMonth).toLocaleString()}
            </p>
            <p style={styles.heroSub}>
              {profitThisMonth >= 0
                ? '✅ Your shop is profitable this month'
                : '⚠️ Expenses exceed collections this month'}
            </p>
          </div>

          {/* Revenue vs Expenses */}
          <div style={styles.grid2}>
            <div style={{ ...styles.statCard, backgroundColor: '#f0fff4' }}>
              <p style={styles.statLabel}>Collected</p>
              <p style={{ ...styles.statValue, color: '#38a169' }}>
                ₦{collectedThisMonth.toLocaleString()}
              </p>
              <p style={styles.statSub}>payments received</p>
            </div>
            <div style={{ ...styles.statCard, backgroundColor: '#fff0f0' }}>
              <p style={styles.statLabel}>Expenses</p>
              <p style={{ ...styles.statValue, color: '#e53e3e' }}>
                ₦{totalExpensesThisMonth.toLocaleString()}
              </p>
              <p style={styles.statSub}>this month</p>
            </div>
          </div>

          {/* Profit bar */}
          {(collectedThisMonth > 0 || totalExpensesThisMonth > 0) && (
            <div style={styles.section}>
              <p style={styles.sectionTitle}>Revenue Breakdown</p>
              <div style={styles.barWrap}>
                {collectedThisMonth > 0 && (
                  <div
                    style={{
                      ...styles.barSegment,
                      backgroundColor: '#38a169',
                      width: `${Math.min(
                        100,
                        Math.round(
                          (collectedThisMonth /
                            Math.max(collectedThisMonth, totalExpensesThisMonth)) *
                            100
                        )
                      )}%`,
                    }}
                  />
                )}
              </div>
              <div style={styles.barLegend}>
                <span style={styles.legendGreen}>■ Collected</span>
                <span style={styles.legendRed}>■ Expenses</span>
              </div>
            </div>
          )}

          {/* Category breakdown */}
          {categoryBreakdown.length > 0 && (
            <div style={styles.section}>
              <p style={styles.sectionTitle}>This Month by Category</p>
              {categoryBreakdown.map(({ cat, total }) => (
                <div key={cat} style={styles.catRow}>
                  <span style={styles.catIcon}>{getCatIcon(cat)}</span>
                  <div style={{ flex: 1 }}>
                    <div style={styles.catTopRow}>
                      <p style={styles.catName}>{cat}</p>
                      <p style={styles.catAmt}>₦{total.toLocaleString()}</p>
                    </div>
                    <div style={styles.catBarWrap}>
                      <div
                        style={{
                          ...styles.catBarFill,
                          width: `${Math.round((total / maxCatTotal) * 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {categoryBreakdown.length === 0 && (
            <div style={styles.section}>
              <p style={styles.empty}>
                No expenses recorded this month yet.{' '}
                <button
                  onClick={() => setTab('add')}
                  style={styles.inlineBtn}
                >
                  Add your first expense →
                </button>
              </p>
            </div>
          )}
        </>
      )}

      {/* ═══════════════════════════════════
          TAB 2 — ADD EXPENSE
      ═══════════════════════════════════ */}
      {tab === 'add' && (
        <div style={styles.section}>
          <p style={styles.sectionTitle}>Record an Expense</p>

          {error && (
            <div style={styles.error}>
              <p>{error}</p>
              {error.includes('migration') && (
                <div style={styles.sqlBox}>
                  <p style={styles.sqlLabel}>Run this in Supabase SQL Editor:</p>
                  <code style={styles.sqlCode}>
                    {`CREATE TABLE IF NOT EXISTS expenses (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  shop_id uuid REFERENCES auth.users(id),
  amount numeric NOT NULL,
  category text NOT NULL,
  note text,
  expense_date date NOT NULL,
  created_at timestamptz DEFAULT now()
);`}
                  </code>
                </div>
              )}
            </div>
          )}

          <form onSubmit={handleAddExpense} style={styles.form}>
            {/* Amount */}
            <div style={styles.inputGroup}>
              <label style={styles.label}>Amount (₦) *</label>
              <input
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="e.g. 15000"
                style={styles.input}
                required
              />
            </div>

            {/* Category */}
            <div style={styles.inputGroup}>
              <label style={styles.label}>Category *</label>
              <div style={styles.categoryGrid}>
                {CATEGORIES.map(c => (
                  <button
                    key={c.label}
                    type="button"
                    onClick={() => setCategory(c.label)}
                    style={
                      category === c.label
                        ? styles.catBtnActive
                        : styles.catBtn
                    }
                  >
                    <span style={{ fontSize: '18px' }}>{c.icon}</span>
                    <span style={{ fontSize: '11px', marginTop: '3px' }}>
                      {c.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Date */}
            <div style={styles.inputGroup}>
              <label style={styles.label}>Date *</label>
              <input
                type="date"
                value={expenseDate}
                onChange={e => setExpenseDate(e.target.value)}
                style={styles.input}
                required
              />
            </div>

            {/* Note */}
            <div style={styles.inputGroup}>
              <label style={styles.label}>Note (optional)</label>
              <input
                type="text"
                value={note}
                onChange={e => setNote(e.target.value)}
                placeholder="e.g. August rent, driver fuel"
                style={styles.input}
              />
            </div>

            <button
              type="submit"
              style={saving ? styles.buttonDisabled : styles.button}
              disabled={saving}
            >
              {saving ? 'Saving...' : 'Record Expense'}
            </button>
          </form>
        </div>
      )}

      {/* ═══════════════════════════════════
          TAB 3 — HISTORY
      ═══════════════════════════════════ */}
      {tab === 'history' && (
        <>
          {Object.keys(byDate).length === 0 ? (
            <div style={styles.section}>
              <p style={styles.empty}>No expenses recorded yet.</p>
            </div>
          ) : (
            Object.entries(byDate).map(([date, items]) => {
              const dayTotal = items.reduce((s, e) => s + e.amount, 0)
              return (
                <div key={date} style={styles.section}>
                  <div style={styles.dateHeader}>
                    <p style={styles.dateLabel}>
                      {new Date(date + 'T00:00:00').toLocaleDateString('en-NG', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </p>
                    <p style={styles.dateTotalAmt}>
                      ₦{dayTotal.toLocaleString()}
                    </p>
                  </div>
                  {items.map(e => (
                    <div key={e.id} style={styles.historyRow}>
                      <span style={styles.historyIcon}>{getCatIcon(e.category)}</span>
                      <div style={{ flex: 1 }}>
                        <p style={styles.historyName}>{e.category}</p>
                        {e.note && (
                          <p style={styles.historyNote}>{e.note}</p>
                        )}
                      </div>
                      <div style={styles.historyRight}>
                        <p style={styles.historyAmt}>
                          ₦{e.amount.toLocaleString()}
                        </p>
                        <button
                          onClick={() => handleDelete(e.id)}
                          style={styles.deleteBtn}
                        >
                          🗑
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )
            })
          )}
        </>
      )}
    </div>
  )
}

const styles = {
  container: {
    maxWidth: '480px',
    margin: '0 auto',
    padding: '20px',
    minHeight: '100vh',
    backgroundColor: '#f0f4f8',
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    fontSize: '16px',
    color: '#888',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    paddingTop: '10px',
  },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },

  // Tabs
  tabs: { display: 'flex', gap: '8px', marginBottom: '20px' },
  tab: {
    flex: 1, padding: '10px 4px', backgroundColor: '#fff',
    color: '#888', border: '1.5px solid #e0e0e0', borderRadius: '10px',
    fontSize: '13px', fontWeight: '600', cursor: 'pointer', textAlign: 'center',
  },
  tabActive: {
    flex: 1, padding: '10px 4px', backgroundColor: '#1a1a2e',
    color: '#fff', border: '1.5px solid #1a1a2e', borderRadius: '10px',
    fontSize: '13px', fontWeight: '600', cursor: 'pointer', textAlign: 'center',
  },

  // Hero
  heroCard: {
    borderRadius: '16px', padding: '28px 24px',
    marginBottom: '16px', textAlign: 'center',
  },
  heroLabel: { color: '#aaa', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' },
  heroAmount: { color: '#fff', fontSize: '40px', fontWeight: '800', marginBottom: '8px' },
  heroSub: { color: '#888', fontSize: '13px' },

  // Stats
  grid2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' },
  statCard: { backgroundColor: '#fff', borderRadius: '14px', padding: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  statLabel: { fontSize: '11px', color: '#888', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' },
  statValue: { fontSize: '22px', fontWeight: '800', color: '#1a1a2e' },
  statSub: { fontSize: '11px', color: '#aaa', marginTop: '2px' },

  section: {
    backgroundColor: '#fff', borderRadius: '16px', padding: '20px',
    marginBottom: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  sectionTitle: {
    fontSize: '13px', fontWeight: '700', color: '#888',
    textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '14px',
  },

  // Revenue bar
  barWrap: { height: '12px', backgroundColor: '#fff0f0', borderRadius: '6px', overflow: 'hidden', marginBottom: '8px' },
  barSegment: { height: '100%', borderRadius: '6px', transition: 'width 0.5s ease' },
  barLegend: { display: 'flex', gap: '16px' },
  legendGreen: { fontSize: '12px', color: '#38a169', fontWeight: '600' },
  legendRed: { fontSize: '12px', color: '#e53e3e', fontWeight: '600' },

  // Category breakdown
  catRow: { display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 0', borderBottom: '1px solid #f0f0f0' },
  catIcon: { fontSize: '20px', flexShrink: 0 },
  catTopRow: { display: 'flex', justifyContent: 'space-between', marginBottom: '5px' },
  catName: { fontSize: '14px', fontWeight: '600', color: '#1a1a2e' },
  catAmt: { fontSize: '14px', fontWeight: '700', color: '#e53e3e' },
  catBarWrap: { height: '5px', backgroundColor: '#f0f0f0', borderRadius: '3px', overflow: 'hidden' },
  catBarFill: { height: '100%', backgroundColor: '#e53e3e', borderRadius: '3px', transition: 'width 0.5s ease' },

  // Add form
  form: { display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '8px' },
  inputGroup: { display: 'flex', flexDirection: 'column', gap: '8px' },
  label: { fontSize: '14px', fontWeight: '600', color: '#1a1a2e' },
  input: { padding: '12px 16px', borderRadius: '10px', border: '1.5px solid #e0e0e0', fontSize: '15px', outline: 'none' },
  categoryGrid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' },
  catBtn: {
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    padding: '10px 4px', backgroundColor: '#f0f4f8', border: '1.5px solid #e0e0e0',
    borderRadius: '10px', cursor: 'pointer', color: '#888',
  },
  catBtnActive: {
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    padding: '10px 4px', backgroundColor: '#1a1a2e', border: '1.5px solid #1a1a2e',
    borderRadius: '10px', cursor: 'pointer', color: '#fff',
  },
  button: {
    padding: '14px', backgroundColor: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '10px', fontSize: '16px', fontWeight: '600', cursor: 'pointer',
  },
  buttonDisabled: {
    padding: '14px', backgroundColor: '#888', color: '#fff',
    border: 'none', borderRadius: '10px', fontSize: '16px', fontWeight: '600', cursor: 'not-allowed',
  },

  // History
  dateHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' },
  dateLabel: { fontSize: '13px', fontWeight: '700', color: '#1a1a2e' },
  dateTotalAmt: { fontSize: '13px', fontWeight: '700', color: '#e53e3e' },
  historyRow: { display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 0', borderBottom: '1px solid #f8f8f8' },
  historyIcon: { fontSize: '20px', flexShrink: 0 },
  historyName: { fontSize: '14px', fontWeight: '600', color: '#1a1a2e' },
  historyNote: { fontSize: '12px', color: '#888', marginTop: '2px' },
  historyRight: { display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 },
  historyAmt: { fontSize: '14px', fontWeight: '700', color: '#e53e3e' },
  deleteBtn: { background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', opacity: 0.5 },

  empty: { color: '#aaa', fontSize: '14px', textAlign: 'center', padding: '10px 0' },
  inlineBtn: { background: 'none', border: 'none', color: '#1a1a2e', fontWeight: '700', cursor: 'pointer', fontSize: '14px' },

  error: { backgroundColor: '#fff0f0', borderRadius: '10px', padding: '12px', marginBottom: '12px' },
  sqlBox: { marginTop: '10px', backgroundColor: '#1a1a2e', borderRadius: '8px', padding: '12px' },
  sqlLabel: { color: '#aaa', fontSize: '11px', marginBottom: '8px' },
  sqlCode: { color: '#38a169', fontSize: '11px', lineHeight: '1.7', whiteSpace: 'pre-wrap', fontFamily: 'monospace' },
}

export default Expenses
