import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, Link } from 'react-router-dom'

function Admin() {
  const [stats, setStats] = useState({ totalOwed: 0, totalCustomers: 0, overdueCount: 0, paidThisMonth: 0 })
  const [topDebtors, setTopDebtors] = useState([])
  const [overdueList, setOverdueList] = useState([])
  const [recentPayments, setRecentPayments] = useState([])
  const [loading, setLoading] = useState(true)
  const [shopName, setShopName] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    loadAdmin()
  }, [])

  const loadAdmin = async () => {
    const { data: userData } = await supabase.auth.getUser()
    setShopName(userData.user?.user_metadata?.shop_name || 'Your Shop')

    const today = new Date().toISOString().split('T')[0]
    const firstOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]

    // All unpaid credits
    const { data: credits } = await supabase
      .from('credits')
      .select('*, customers(full_name, phone)')
      .eq('status', 'unpaid')

    if (credits) {
      const totalOwed = credits.reduce((sum, c) => sum + (c.amount - c.amount_paid), 0)
      const overdue = credits.filter(c => c.due_date && c.due_date < today)

      // Top debtors sorted by balance
      const sorted = [...credits]
        .map(c => ({ ...c, balance: c.amount - c.amount_paid }))
        .sort((a, b) => b.balance - a.balance)
        .slice(0, 5)

      setStats(s => ({ ...s, totalOwed, overdueCount: overdue.length }))
      setTopDebtors(sorted)
      setOverdueList(overdue.slice(0, 10))
    }

    // Customer count
    const { count } = await supabase
      .from('customers')
      .select('*', { count: 'exact', head: true })
    setStats(s => ({ ...s, totalCustomers: count || 0 }))

    // Payments this month
    const { data: payments } = await supabase
      .from('payments')
      .select('amount')
      .gte('paid_at', firstOfMonth)
    if (payments) {
      const paidThisMonth = payments.reduce((sum, p) => sum + p.amount, 0)
      setStats(s => ({ ...s, paidThisMonth }))
      setRecentPayments(payments)
    }

    setLoading(false)
  }

  if (loading) return <div style={styles.loading}>Loading...</div>

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <Link to="/dashboard" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title}>Admin Summary</h2>
        <div />
      </div>

      <p style={styles.shopLabel}>{shopName}</p>

      {/* Stats Grid */}
      <div style={styles.grid}>
        <div style={styles.statCard}>
          <p style={styles.statLabel}>Total Owed</p>
          <p style={styles.statValue}>₦{stats.totalOwed.toLocaleString()}</p>
        </div>
        <div style={{ ...styles.statCard, backgroundColor: stats.overdueCount > 0 ? '#fff0f0' : '#f0fff4' }}>
          <p style={styles.statLabel}>Overdue</p>
          <p style={{ ...styles.statValue, color: stats.overdueCount > 0 ? '#e53e3e' : '#38a169' }}>
            {stats.overdueCount}
          </p>
        </div>
        <div style={styles.statCard}>
          <p style={styles.statLabel}>Customers</p>
          <p style={styles.statValue}>{stats.totalCustomers}</p>
        </div>
        <div style={{ ...styles.statCard, backgroundColor: '#f0fff4' }}>
          <p style={styles.statLabel}>Collected (Month)</p>
          <p style={{ ...styles.statValue, color: '#38a169' }}>₦{stats.paidThisMonth.toLocaleString()}</p>
        </div>
      </div>

      {/* Top Debtors */}
      <div style={styles.section}>
        <p style={styles.sectionTitle}>🏆 Top Debtors</p>
        {topDebtors.length === 0 ? (
          <p style={styles.empty}>No outstanding debts!</p>
        ) : topDebtors.map((c, i) => (
          <div
            key={c.id}
            style={styles.row}
            onClick={() => navigate(`/add-credit?customerId=${c.customer_id}&customerName=${c.customers?.full_name}`)}
          >
            <div style={styles.rank}>#{i + 1}</div>
            <div style={styles.rowInfo}>
              <p style={styles.rowName}>{c.customers?.full_name}</p>
              <p style={styles.rowSub}>{c.customers?.phone || 'No phone'}</p>
            </div>
            <p style={styles.rowAmount}>₦{c.balance.toLocaleString()}</p>
          </div>
        ))}
      </div>

      {/* Overdue Customers */}
      {overdueList.length > 0 && (
        <div style={styles.section}>
          <p style={styles.sectionTitle}>⚠️ Overdue Customers</p>
          {overdueList.map(c => (
            <div
              key={c.id}
              style={{ ...styles.row, borderLeft: '3px solid #e53e3e', paddingLeft: '12px' }}
              onClick={() => navigate(`/add-credit?customerId=${c.customer_id}&customerName=${c.customers?.full_name}`)}
            >
              <div style={styles.rowInfo}>
                <p style={styles.rowName}>{c.customers?.full_name}</p>
                <p style={{ ...styles.rowSub, color: '#e53e3e' }}>Due: {c.due_date}</p>
              </div>
              <p style={styles.rowAmount}>₦{(c.amount - c.amount_paid).toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}

      {/* Quick Actions */}
      <div style={styles.section}>
        <p style={styles.sectionTitle}>Quick Actions</p>
        <div style={styles.actionGrid}>
  <Link to="/add-customer" style={styles.actionBtn}>+ Add Customer</Link>
  <Link to="/customers" style={styles.actionBtnOutline}>View All</Link>
  <Link to="/customers?filter=overdue" style={{ ...styles.actionBtn, backgroundColor: '#e53e3e' }}>
    Overdue List
  </Link>
  <Link to="/broadcast" style={{ ...styles.actionBtn, backgroundColor: '#25D366' }}>
    📢 Broadcast
  </Link>
</div>
      </div>
    </div>
  )
}

const styles = {
  container: { maxWidth: '480px', margin: '0 auto', padding: '20px', minHeight: '100vh', backgroundColor: '#f0f4f8' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px', paddingTop: '10px' },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },
  shopLabel: { fontSize: '13px', color: '#888', textAlign: 'center', marginBottom: '20px' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '20px' },
  statCard: { backgroundColor: '#fff', borderRadius: '12px', padding: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  statLabel: { fontSize: '11px', color: '#888', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' },
  statValue: { fontSize: '20px', fontWeight: '800', color: '#1a1a2e' },
  section: { backgroundColor: '#fff', borderRadius: '16px', padding: '20px', marginBottom: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  sectionTitle: { fontSize: '13px', fontWeight: '700', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '16px' },
  row: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 0', borderBottom: '1px solid #f0f0f0', cursor: 'pointer' },
  rank: { width: '28px', height: '28px', borderRadius: '50%', backgroundColor: '#f0f4f8', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: '700', color: '#1a1a2e', flexShrink: 0 },
  rowInfo: { flex: 1 },
  rowName: { fontWeight: '600', fontSize: '14px', color: '#1a1a2e' },
  rowSub: { fontSize: '12px', color: '#888', marginTop: '2px' },
  rowAmount: { fontWeight: '700', fontSize: '15px', color: '#1a1a2e' },
  empty: { color: '#888', fontSize: '14px', textAlign: 'center', padding: '10px 0' },
  actionGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' },
  actionBtn: { padding: '12px', backgroundColor: '#1a1a2e', color: '#fff', borderRadius: '10px', textAlign: 'center', textDecoration: 'none', fontWeight: '600', fontSize: '13px' },
  actionBtnOutline: { padding: '12px', backgroundColor: '#fff', color: '#1a1a2e', border: '1.5px solid #1a1a2e', borderRadius: '10px', textAlign: 'center', textDecoration: 'none', fontWeight: '600', fontSize: '13px' },
  loading: { display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', fontSize: '16px', color: '#888' },
}

export default Admin