import { useState, useEffect, useRef } from 'react'
import { supabase } from '../lib/supabase'

const MONTHLY_PRICE = 5000
const YEARLY_PRICE = 48000
const YEARLY_MONTHLY_EQUIV = Math.round(YEARLY_PRICE / 12)
const PAYSTACK_KEY = import.meta.env.VITE_PAYSTACK_PUBLIC_KEY || 'pk_test_458e5e2cfce9da301e43b789e906c1b6251b95e4'

const PRO_FEATURES = [
  { icon: '🧾', title: 'Unlimited Invoices', sub: 'Generate, print, share via WhatsApp or email — no limits' },
  { icon: '📊', title: 'Full Analytics', sub: 'Revenue trends, top debtors, best payers, product insights' },
  { icon: '💸', title: 'Expense Tracking', sub: 'Track rent, transport, wages — see your real profit' },
  { icon: '📦', title: 'Inventory Management', sub: 'Stock levels, low-stock alerts, cost vs selling price' },
  { icon: '⏰', title: 'Auto Payment Reminders', sub: 'Automatic WhatsApp ping 3 days before credit is due' },
  { icon: '📄', title: 'PDF Monthly Export', sub: 'Full report of credits, payments and collections' },
  { icon: '👥', title: 'Multi-Staff Access', sub: 'Worker login (view only) vs admin (full control)' },
  { icon: '🔒', title: 'Data Backup & Restore', sub: 'Export and restore all your shop data any time' },
  { icon: '🌍', title: 'Local Languages', sub: 'Switch between English, Hausa, Yoruba, Igbo' },
  { icon: '🏪', title: 'Unlimited Customers', sub: 'No cap — add as many customers as your business needs' },
]

function ProUpgrade({ onClose, source = 'manual' }) {
  const [plan, setPlan] = useState('yearly')
  const [loading, setLoading] = useState(false)
  const [status, setStatus] = useState('')
  const [error, setError] = useState('')
  const [userEmail, setUserEmail] = useState('')
  const [userId, setUserId] = useState('')
  const pollRef = useRef(null)

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUserEmail(data?.user?.email || '')
      setUserId(data?.user?.id || '')
    })

    // Clean up polling on unmount
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [])

  const handleClose = () => {
    if (pollRef.current) clearInterval(pollRef.current)
    if (onClose) onClose()
    else window.history.back()
  }

  const startPolling = (selectedPlan) => {
    // Poll localStorage every 800ms from the MAIN PAGE
    // This is the key fix — the main page redirects itself
    // instead of waiting for the iframe callback to do it
    pollRef.current = setInterval(() => {
      try {
        const paid = localStorage.getItem('tally_payment_confirmed')
        if (paid === 'yes') {
             console.log('STEP 2: poll detected payment')

          clearInterval(pollRef.current)
          localStorage.removeItem('tally_payment_confirmed')
          setStatus('Payment confirmed! ✅ Activating Pro...')

          // Calculate expiry
          const months = selectedPlan === 'yearly' ? 12 : 1
          const expiry = new Date()
          expiry.setMonth(expiry.getMonth() + months)
          const expiryStr = expiry.toISOString()

          // Write Pro status
          localStorage.setItem('tally_pro_expiry', expiryStr)
          localStorage.setItem('tally_pro_plan', selectedPlan)

          // Sync to Supabase in background
          supabase.auth.updateUser({
            data: { pro_expiry: expiryStr, pro_plan: selectedPlan },
          }).catch(() => {})

          // THE MAIN PAGE does the redirect — not the iframe
          if (onClose) onClose()
          window.location.href = window.location.origin + '/pro-success'
        }
      } catch (e) {}
    }, 800)
  }
  const handleUpgrade = () => {
  setError('')
  setLoading(true)
  setStatus('Opening payment...')

  if (!userEmail) {
    setError('Not logged in. Please refresh.')
    setLoading(false)
    setStatus('')
    return
  }

  // Remove any old Paystack script and load a completely fresh one every time
  const oldScript = document.getElementById('paystack-script')
  if (oldScript) oldScript.remove()

  const script = document.createElement('script')
  script.src = 'https://js.paystack.co/v1/inline.js'
  script.id = 'paystack-script'
  script.onload = () => {
    startPolling(plan)
    launchPaystack()
  }
  script.onerror = () => {
    setError('Could not load payment system. Check your internet and try again.')
    setLoading(false)
    setStatus('')
  }
  document.body.appendChild(script)
}

const launchPaystack = () => {
  const PaystackPop = window.PaystackPop
  if (!PaystackPop) {
    setError('Payment system not ready. Please try again.')
    setLoading(false)
    setStatus('')
    return
  }

  const amount = plan === 'yearly' ? YEARLY_PRICE : MONTHLY_PRICE
  const ref = 'TALLY-' + (userId.slice(0, 8) || 'user') + '-' + Date.now()
  const selectedPlan = plan

  try { localStorage.removeItem('tally_payment_confirmed') } catch (e) {}

  const handler = PaystackPop.setup({
    key: PAYSTACK_KEY,
    email: userEmail,
    amount: amount * 100,
    currency: 'NGN',
    ref,
    onSuccess: function (response) {
      console.log('STEP 1: onSuccess fired', response)
      try {
        localStorage.setItem('tally_payment_confirmed', 'yes')
        localStorage.setItem('tally_pro_ref', response.reference)
        localStorage.setItem('tally_pro_plan', selectedPlan)
      } catch (e) {}
    },
    onCancel: function () {
      setLoading(false)
      setStatus('')
    },
  })

  handler.openIframe()
}

  

    

  return (
    <div style={styles.page}>
      <div style={styles.topRow}>
        <button onClick={handleClose} style={styles.backBtn}>← Back</button>
      </div>

      <div style={styles.proHeader}>
        <div style={styles.crownCircle}>👑</div>
        <h2 style={styles.proTitle}>Tally Pro</h2>
        <p style={styles.proSub}>Everything your business needs to grow — in one app</p>
      </div>

      {source === 'invoice_limit' && (
        <div style={styles.nudgeBanner}>
          <p style={styles.nudgeText}>🧾 You've used all 3 free invoices. Upgrade for unlimited.</p>
        </div>
      )}
      {source === 'customer_limit' && (
        <div style={styles.nudgeBanner}>
          <p style={styles.nudgeText}>👥 You've reached 500 customers. Upgrade for unlimited.</p>
        </div>
      )}
      {source === 'analytics' && (
        <div style={styles.nudgeBanner}>
          <p style={styles.nudgeText}>📊 Full analytics are a Pro feature.</p>
        </div>
      )}

      <div style={styles.planToggle}>
        <button
          onClick={() => setPlan('monthly')}
          style={plan === 'monthly' ? styles.planBtnActive : styles.planBtn}
        >
          Monthly
        </button>
        <button
          onClick={() => setPlan('yearly')}
          style={plan === 'yearly' ? styles.planBtnActive : styles.planBtn}
        >
          Yearly <span style={styles.saveBadge}>Save 20%</span>
        </button>
      </div>

      <div style={styles.priceCard}>
        {plan === 'yearly' ? (
          <>
            <p style={styles.priceMain}>
              ₦{YEARLY_MONTHLY_EQUIV.toLocaleString()}
              <span style={styles.pricePer}>/month</span>
            </p>
            <p style={styles.priceSub}>₦{YEARLY_PRICE.toLocaleString()} billed once a year</p>
            <p style={styles.priceSaving}>
              Save ₦{((MONTHLY_PRICE * 12) - YEARLY_PRICE).toLocaleString()} vs monthly
            </p>
          </>
        ) : (
          <>
            <p style={styles.priceMain}>
              ₦{MONTHLY_PRICE.toLocaleString()}
              <span style={styles.pricePer}>/month</span>
            </p>
            <p style={styles.priceSub}>Billed monthly, cancel any time</p>
          </>
        )}
      </div>

      <div style={styles.featureList}>
        {PRO_FEATURES.map((f, i) => (
          <div key={i} style={styles.featureRow}>
            <span style={styles.featureIcon}>{f.icon}</span>
            <div>
              <p style={styles.featureTitle}>{f.title}</p>
              <p style={styles.featureSub}>{f.sub}</p>
            </div>
          </div>
        ))}
      </div>

      {error && (
        <div style={styles.errorBox}>
          <p style={styles.errorText}>{error}</p>
        </div>
      )}
      {status && !error && (
        <p style={styles.statusText}>{status}</p>
      )}

      <button
        onClick={handleUpgrade}
        disabled={loading}
        style={loading ? styles.ctaDisabled : styles.cta}
      >
        {loading
          ? (status || 'Please wait...')
          : 'Upgrade to Pro — ₦' + (plan === 'yearly' ? YEARLY_PRICE.toLocaleString() : MONTHLY_PRICE.toLocaleString()) + '/' + (plan === 'yearly' ? 'yr' : 'mo')}
      </button>

      <p style={styles.guarantee}>🔒 Secured by Paystack · Cancel any time · Instant activation</p>
    </div>
  )
}

const styles = {
  page: {
    maxWidth: '480px',
    margin: '0 auto',
    padding: '20px',
    minHeight: '100vh',
    backgroundColor: '#f0f4f8',
  },
  topRow: { marginBottom: '16px' },
  backBtn: {
    background: 'none', border: 'none', color: '#1a1a2e',
    fontWeight: '600', fontSize: '15px', cursor: 'pointer', padding: 0,
  },
  proHeader: { textAlign: 'center', marginBottom: '20px' },
  crownCircle: {
    width: '64px', height: '64px', borderRadius: '50%', backgroundColor: '#fef3c7',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: '28px', margin: '0 auto 12px',
  },
  proTitle: { fontSize: '24px', fontWeight: '800', color: '#1a1a2e', marginBottom: '6px' },
  proSub: { fontSize: '14px', color: '#888', lineHeight: '1.5' },
  nudgeBanner: {
    backgroundColor: '#fef3c7', borderRadius: '12px',
    padding: '12px 16px', marginBottom: '16px',
  },
  nudgeText: { fontSize: '13px', color: '#92400e', lineHeight: '1.5' },
  planToggle: {
    display: 'flex', gap: '8px', marginBottom: '16px',
    backgroundColor: '#f0f4f8', borderRadius: '12px', padding: '4px',
  },
  planBtn: {
    flex: 1, padding: '10px', border: 'none', borderRadius: '10px',
    backgroundColor: 'transparent', color: '#888', fontWeight: '600',
    fontSize: '14px', cursor: 'pointer',
  },
  planBtnActive: {
    flex: 1, padding: '10px', border: 'none', borderRadius: '10px',
    backgroundColor: '#1a1a2e', color: '#ffffff', fontWeight: '600',
    fontSize: '14px', cursor: 'pointer',
  },
  saveBadge: {
    marginLeft: '6px', backgroundColor: '#38a169', color: '#fff',
    fontSize: '10px', fontWeight: '700', padding: '2px 6px', borderRadius: '10px',
  },
  priceCard: {
    backgroundColor: '#ffffff', borderRadius: '14px', padding: '20px',
    textAlign: 'center', marginBottom: '20px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  priceMain: { fontSize: '32px', fontWeight: '800', color: '#1a1a2e', marginBottom: '4px' },
  pricePer: { fontSize: '16px', fontWeight: '400', color: '#888' },
  priceSub: { fontSize: '13px', color: '#888' },
  priceSaving: { fontSize: '13px', color: '#38a169', fontWeight: '600', marginTop: '4px' },
  featureList: { marginBottom: '24px' },
  featureRow: {
    display: 'flex', gap: '14px', padding: '10px 12px',
    borderBottom: '1px solid #e0e0e0', alignItems: 'flex-start',
    backgroundColor: '#ffffff', marginBottom: '2px', borderRadius: '8px',
  },
  featureIcon: { fontSize: '20px', flexShrink: 0, marginTop: '1px' },
  featureTitle: { fontSize: '14px', fontWeight: '700', color: '#1a1a2e', marginBottom: '2px' },
  featureSub: { fontSize: '12px', color: '#888', lineHeight: '1.4' },
  errorBox: {
    backgroundColor: '#fff0f0', borderRadius: '10px',
    padding: '12px', marginBottom: '12px',
  },
  errorText: { color: '#e53e3e', fontSize: '13px', textAlign: 'center' },
  statusText: {
    color: '#38a169', fontSize: '14px', textAlign: 'center',
    marginBottom: '12px', fontWeight: '700',
  },
  cta: {
    width: '100%', padding: '16px', backgroundColor: '#1a1a2e', color: '#ffffff',
    border: 'none', borderRadius: '14px', fontSize: '16px', fontWeight: '700',
    cursor: 'pointer', marginBottom: '12px',
  },
  ctaDisabled: {
    width: '100%', padding: '16px', backgroundColor: '#888', color: '#ffffff',
    border: 'none', borderRadius: '14px', fontSize: '16px', fontWeight: '700',
    cursor: 'not-allowed', marginBottom: '12px',
  },
  guarantee: { textAlign: 'center', fontSize: '12px', color: '#aaa', lineHeight: '1.5' },
}

export default ProUpgrade
