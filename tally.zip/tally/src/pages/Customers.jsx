import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, Link, useSearchParams } from 'react-router-dom'
import ProBadge from '../components/ProBadge'
import ProNudgeCard from '../components/ProNudgecard'

function Customers() {
  const [customers, setCustomers] = useState([])
  const [credits, setCredits] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const filterOverdue = searchParams.get('filter') === 'overdue'

  useEffect(() => {
    fetchCustomers()
    fetchCredits()
  }, [])

  const fetchCustomers = async () => {
    const { data } = await supabase
      .from('customers')
      .select('*')
      .order('created_at', { ascending: false })
    setCustomers(data || [])
    setLoading(false)
  }

  const fetchCredits = async () => {
    const today = new Date().toISOString().split('T')[0]
    const { data } = await supabase
      .from('credits')
      .select('*')
      .eq('status', 'unpaid')
      .lt('due_date', today)
    setCredits(data || [])
  }

  const overdueCustomerIds = credits.map(c => c.customer_id)

  const filtered = customers.filter(c => {
    const matchesSearch =
      c.full_name.toLowerCase().includes(search.toLowerCase()) ||
      (c.phone && c.phone.includes(search))
    if (filterOverdue) return overdueCustomerIds.includes(c.id) && matchesSearch
    return matchesSearch
  })

  // Insert nudge card after 5th customer row
  const NUDGE_POSITION = 5

  if (loading) return <div style={styles.loading}>Loading...</div>

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <Link to="/dashboard" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title}>
          {filterOverdue ? '⚠️ Overdue' : 'Customers'}
        </h2>
        <div style={styles.headerRight}>
          <ProBadge />
          <Link to="/add-customer" style={styles.addBtn}>+ Add</Link>
        </div>
      </div>

      <input
        type="text"
        placeholder="Search by name or phone..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={styles.search}
      />

      {filterOverdue && (
        <div style={styles.overdueBanner}>
          ⚠️ Showing {filtered.length} overdue customer{filtered.length !== 1 ? 's' : ''}
        </div>
      )}

      {filtered.length === 0 ? (
        <div style={styles.empty}>
          <p style={styles.emptyText}>
            {search
              ? 'No customers match your search'
              : filterOverdue
              ? 'No overdue customers!'
              : 'No customers yet'}
          </p>
          {!search && !filterOverdue && (
            <Link to="/add-customer" style={styles.emptyBtn}>
              Add your first customer
            </Link>
          )}
        </div>
      ) : (
        <div style={styles.list}>
          {filtered.map((customer, index) => (
            <>
              {/* Nudge card after 5th customer, only on main list */}
              {index === NUDGE_POSITION && !filterOverdue && !search && (
                <ProNudgeCard key="nudge" trigger="halfway" />
              )}

              <div
                key={customer.id}
                style={{
                  ...styles.card,
                  borderLeft: overdueCustomerIds.includes(customer.id)
                    ? '4px solid #e53e3e'
                    : '4px solid transparent',
                }}
                onClick={() =>
                  navigate(
                    `/add-credit?customerId=${customer.id}&customerName=${encodeURIComponent(customer.full_name)}`
                  )
                }
              >
                <div style={styles.avatar}>
                  {customer.full_name.charAt(0).toUpperCase()}
                </div>
                <div style={styles.info}>
                  <p style={styles.name}>{customer.full_name}</p>
                  <p style={styles.phone}>{customer.phone || 'No phone'}</p>
                  {customer.notes && (
                    <p style={styles.notes}>{customer.notes}</p>
                  )}
                  {customer.wishlist && (
                    <p style={styles.wishlist}>🛍️ {customer.wishlist}</p>
                  )}
                  {overdueCustomerIds.includes(customer.id) && (
                    <p style={styles.overdueTag}>⚠️ Overdue</p>
                  )}
                </div>
                <div style={styles.arrow}>›</div>
              </div>
            </>
          ))}
        </div>
      )}
    </div>
  )
}

const styles = {
  container: {
    maxWidth: '480px',
    margin: '0 auto',
    padding: '20px',
    minHeight: '100vh',
    backgroundColor: '#f0f4f8',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    paddingTop: '10px',
  },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },
  headerRight: { display: 'flex', alignItems: 'center', gap: '8px' },
  addBtn: {
    color: '#ffffff',
    backgroundColor: '#1a1a2e',
    textDecoration: 'none',
    fontWeight: '600',
    fontSize: '14px',
    padding: '8px 16px',
    borderRadius: '8px',
  },
  search: {
    width: '100%',
    padding: '12px 16px',
    borderRadius: '12px',
    border: '1.5px solid #e0e0e0',
    fontSize: '15px',
    outline: 'none',
    marginBottom: '16px',
    backgroundColor: '#ffffff',
    boxSizing: 'border-box',
  },
  overdueBanner: {
    backgroundColor: '#fff0f0',
    color: '#e53e3e',
    padding: '10px 16px',
    borderRadius: '10px',
    fontSize: '14px',
    fontWeight: '600',
    marginBottom: '16px',
  },
  list: { display: 'flex', flexDirection: 'column', gap: '10px' },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: '14px',
    padding: '16px',
    display: 'flex',
    alignItems: 'center',
    gap: '14px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
    cursor: 'pointer',
  },
  avatar: {
    width: '44px',
    height: '44px',
    borderRadius: '50%',
    backgroundColor: '#1a1a2e',
    color: '#ffffff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '18px',
    fontWeight: '700',
    flexShrink: 0,
  },
  info: { flex: 1 },
  name: { fontWeight: '700', fontSize: '15px', color: '#1a1a2e', marginBottom: '2px' },
  phone: { fontSize: '13px', color: '#888', marginBottom: '2px' },
  notes: { fontSize: '12px', color: '#aaa', fontStyle: 'italic' },
  wishlist: { fontSize: '12px', color: '#4a90e2', marginTop: '2px' },
  overdueTag: { fontSize: '12px', color: '#e53e3e', fontWeight: '600', marginTop: '4px' },
  arrow: { fontSize: '22px', color: '#ccc', fontWeight: '300' },
  empty: { textAlign: 'center', padding: '60px 20px' },
  emptyText: { color: '#888', fontSize: '15px', marginBottom: '16px' },
  emptyBtn: {
    backgroundColor: '#1a1a2e',
    color: '#ffffff',
    padding: '12px 24px',
    borderRadius: '10px',
    textDecoration: 'none',
    fontWeight: '600',
    fontSize: '14px',
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    fontSize: '16px',
    color: '#888',
  },
}

export default Customers
