import { useEffect, useState, useRef } from 'react'
import { supabase } from '../lib/supabase'
import { useSearchParams, Link } from 'react-router-dom'

function Invoice() {
  const [searchParams] = useSearchParams()
  const creditId = searchParams.get('creditId')
  const customerId = searchParams.get('customerId')
  const customerName = searchParams.get('customerName')

  const [credit, setCredit] = useState(null)
  const [customer, setCustomer] = useState(null)
  const [shopName, setShopName] = useState('')
  const [ownerName, setOwnerName] = useState('')
  const [loading, setLoading] = useState(true)
  const [invoiceNumber, setInvoiceNumber] = useState('')

  useEffect(() => { loadAll() }, [])

  const loadAll = async () => {
    const { data: userData } = await supabase.auth.getUser()
    const meta = userData.user?.user_metadata || {}
    setShopName(meta.shop_name || 'Our Shop')
    setOwnerName(meta.owner_name || '')
    setInvoiceNumber('INV-' + Date.now().toString().slice(-6))

    if (creditId) {
      const { data: creditData } = await supabase
        .from('credits')
        .select('*, payments(*)')
        .eq('id', creditId)
        .single()
      if (creditData) setCredit(creditData)
    }

    if (customerId) {
      const { data: custData } = await supabase
        .from('customers')
        .select('*')
        .eq('id', customerId)
        .single()
      if (custData) setCustomer(custData)
    }

    setLoading(false)
  }

  const balance = credit ? credit.amount - credit.amount_paid : 0
  const today = new Date().toLocaleDateString('en-NG', { day: 'numeric', month: 'long', year: 'numeric' })

  // Parse notes — format is "item description — extra notes" or just notes
  const parseNotes = (notes) => {
    if (!notes) return { item: '', extra: '' }
    const parts = notes.split(' — ')
    if (parts.length >= 2) return { item: parts[0], extra: parts.slice(1).join(' — ') }
    return { item: notes, extra: '' }
  }
  const { item: itemBought, extra: extraNotes } = parseNotes(credit?.notes)

  const handleWhatsApp = () => {
    const phone = customer?.phone ? customer.phone.replace(/^0/, '234') : ''
    const msg =
      `🧾 *INVOICE from ${shopName}*\n` +
      `Invoice No: ${invoiceNumber}\n` +
      `Date: ${today}\n\n` +
      `Customer: ${customerName}\n` +
      (itemBought ? `Items: ${itemBought}\n` : '') +
      (extraNotes ? `Notes: ${extraNotes}\n` : '') +
      `─────────────────\n` +
      `Total Amount: ₦${credit?.amount?.toLocaleString()}\n` +
      `Amount Paid: ₦${credit?.amount_paid?.toLocaleString()}\n` +
      `Balance Due: ₦${balance.toLocaleString()}\n` +
      (credit?.due_date ? `Due Date: ${credit.due_date}\n` : '') +
      `─────────────────\n` +
      `Thank you for your business! 🙏\n— ${shopName}`
    window.open(phone ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
  }

  const handlePrint = () => window.print()

  const handleDownload = () => {
    const html = buildPrintHTML()
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${invoiceNumber}-${customerName}.html`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleEmail = () => {
    const subject = encodeURIComponent(`Invoice ${invoiceNumber} from ${shopName}`)
    const body = encodeURIComponent(
      `Dear ${customerName},\n\nPlease find your invoice details below.\n\n` +
      `Invoice No: ${invoiceNumber}\nDate: ${today}\n` +
      (itemBought ? `Items: ${itemBought}\n` : '') +
      (extraNotes ? `Notes: ${extraNotes}\n` : '') +
      `\nTotal Amount: ₦${credit?.amount?.toLocaleString()}\n` +
      `Amount Paid: ₦${credit?.amount_paid?.toLocaleString()}\n` +
      `Balance Due: ₦${balance.toLocaleString()}\n` +
      (credit?.due_date ? `Due Date: ${credit.due_date}\n` : '') +
      `\nThank you for your business!\n\n${shopName}`
    )
    window.open(`mailto:?subject=${subject}&body=${body}`)
  }

  const buildPrintHTML = () => `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>${invoiceNumber}</title>
  <style>
    body { font-family: 'Segoe UI', sans-serif; margin: 0; padding: 32px; color: #1a1a2e; background: #fff; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; }
    .shop { font-size: 24px; font-weight: 800; }
    .inv-label { font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; text-align: right; }
    .inv-number { font-size: 18px; font-weight: 700; text-align: right; }
    .divider { border: none; border-top: 1.5px solid #e0e0e0; margin: 20px 0; }
    .row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 14px; }
    .label { color: #888; }
    .value { font-weight: 600; }
    .balance-row { display: flex; justify-content: space-between; margin-top: 16px; padding-top: 16px; border-top: 2px solid #1a1a2e; font-size: 18px; font-weight: 800; }
    .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #aaa; }
    .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; }
    .paid { background: #c6f6d5; color: #276749; }
    .unpaid { background: #fff0f0; color: #e53e3e; }
    .items-box { background: #f8f9fa; border-radius: 8px; padding: 14px 16px; margin: 16px 0; border-left: 4px solid #1a1a2e; }
    .items-title { font-size: 11px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .items-text { font-size: 14px; font-weight: 600; color: #1a1a2e; }
    .notes-text { font-size: 13px; color: #555; margin-top: 4px; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="shop">${shopName}</div>
      ${ownerName ? `<div style="color:#888;font-size:13px;margin-top:4px;">${ownerName}</div>` : ''}
    </div>
    <div>
      <div class="inv-label">Invoice</div>
      <div class="inv-number">${invoiceNumber}</div>
      <div style="font-size:12px;color:#888;text-align:right;margin-top:4px;">${today}</div>
    </div>
  </div>

  <hr class="divider"/>

  <div style="margin-bottom:20px;">
    <div style="font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Billed To</div>
    <div style="font-size:16px;font-weight:700;">${customerName}</div>
    ${customer?.phone ? `<div style="font-size:13px;color:#888;margin-top:2px;">${customer.phone}</div>` : ''}
    ${customer?.address ? `<div style="font-size:13px;color:#888;">${customer.address}</div>` : ''}
  </div>

  <hr class="divider"/>

  ${itemBought || extraNotes ? `
  <div class="items-box">
    <div class="items-title">Items / Description</div>
    ${itemBought ? `<div class="items-text">📦 ${itemBought}</div>` : ''}
    ${extraNotes ? `<div class="notes-text">📝 ${extraNotes}</div>` : ''}
  </div>
  ` : ''}

  <div class="row"><span class="label">Total Credit Amount</span><span class="value">₦${credit?.amount?.toLocaleString()}</span></div>
  <div class="row">
    <span class="label">Amount Paid</span>
    <span class="value" style="color:${credit?.amount_paid > 0 ? '#38a169' : '#e53e3e'};">
      ₦${credit?.amount_paid?.toLocaleString()} ${credit?.amount_paid === 0 ? '(No deposit made)' : ''}
    </span>
  </div>
  ${credit?.due_date ? `<div class="row"><span class="label">Due Date</span><span class="value">${credit.due_date}</span></div>` : ''}
  <div class="row">
    <span class="label">Status</span>
    <span class="status ${balance <= 0 ? 'paid' : 'unpaid'}">${balance <= 0 ? 'FULLY PAID' : 'OUTSTANDING'}</span>
  </div>

  <div class="balance-row">
    <span>Balance Due</span>
    <span style="color:${balance <= 0 ? '#38a169' : '#e53e3e'};">₦${balance.toLocaleString()}</span>
  </div>

  ${credit?.payments?.length > 0 ? `
  <div style="margin-top:28px;">
    <div style="font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px;">Payment History</div>
    ${credit.payments.map(p => `
      <div class="row" style="padding:6px 0;border-bottom:1px solid #f0f0f0;">
        <span class="label">${new Date(p.paid_at).toLocaleDateString()}</span>
        <span class="value" style="color:#38a169;">₦${p.amount.toLocaleString()}</span>
      </div>
    `).join('')}
  </div>` : ''}

  <hr class="divider" style="margin-top:28px;"/>
  <div style="font-size:11px;color:#aaa;text-align:center;margin-top:8px;">
    Both parties acknowledge the accuracy of this invoice.
  </div>

  <div class="footer">
    <p>Thank you for your business 🙏</p>
    <p style="margin-top:4px;">${shopName}${ownerName ? ' · ' + ownerName : ''}</p>
  </div>
</body>
</html>`

  if (loading) return <div style={styles.loading}>Generating invoice...</div>

  return (
    <>
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .invoice-card { box-shadow: none !important; border: 1px solid #e0e0e0 !important; }
        }
      `}</style>

      <div style={styles.container}>
        <div style={styles.header} className="no-print">
          <Link to={`/add-credit?customerId=${customerId}&customerName=${customerName}`} style={styles.backBtn}>← Back</Link>
          <h2 style={styles.title}>Invoice</h2>
          <div />
        </div>

        <div style={styles.invoiceCard} className="invoice-card">

          {/* Shop header */}
          <div style={styles.invoiceHeader}>
            <div>
              <p style={styles.shopName}>{shopName}</p>
              {ownerName && <p style={styles.ownerName}>{ownerName}</p>}
            </div>
            <div style={styles.invMeta}>
              <p style={styles.invLabel}>Invoice</p>
              <p style={styles.invNumber}>{invoiceNumber}</p>
              <p style={styles.invDate}>{today}</p>
            </div>
          </div>

          <div style={styles.divider} />

          {/* Billed to */}
          <div style={styles.billedTo}>
            <p style={styles.billedLabel}>Billed To</p>
            <p style={styles.billedName}>{customerName}</p>
            {customer?.phone && <p style={styles.billedSub}>{customer.phone}</p>}
            {customer?.address && <p style={styles.billedSub}>{customer.address}</p>}
          </div>

          <div style={styles.divider} />

          {/* ── Items / Description box ── */}
          {(itemBought || extraNotes) && (
            <div style={styles.itemsBox}>
              <p style={styles.itemsLabel}>Items / Description</p>
              {itemBought && (
                <p style={styles.itemText}>📦 {itemBought}</p>
              )}
              {extraNotes && (
                <p style={styles.notesText}>📝 {extraNotes}</p>
              )}
            </div>
          )}

          {/* Amounts */}
          <div style={styles.amountRows}>
            <div style={styles.amountRow}>
              <span style={styles.amountLabel}>Total Credit Amount</span>
              <span style={styles.amountValue}>₦{credit?.amount?.toLocaleString()}</span>
            </div>
            <div style={styles.amountRow}>
              <span style={styles.amountLabel}>Amount Paid</span>
              <span style={{
                ...styles.amountValue,
                color: credit?.amount_paid > 0 ? '#38a169' : '#e53e3e'
              }}>
                ₦{credit?.amount_paid?.toLocaleString()}
                {credit?.amount_paid === 0 && (
                  <span style={styles.noPaymentNote}> — no deposit made</span>
                )}
              </span>
            </div>
            {credit?.due_date && (
              <div style={styles.amountRow}>
                <span style={styles.amountLabel}>Due Date</span>
                <span style={styles.amountValue}>{credit.due_date}</span>
              </div>
            )}
            <div style={styles.amountRow}>
              <span style={styles.amountLabel}>Status</span>
              <span style={{
                ...styles.statusBadge,
                backgroundColor: balance <= 0 ? '#c6f6d5' : '#fff0f0',
                color: balance <= 0 ? '#276749' : '#e53e3e',
              }}>
                {balance <= 0 ? 'FULLY PAID' : 'OUTSTANDING'}
              </span>
            </div>
          </div>

          {/* Balance due */}
          <div style={styles.balanceRow}>
            <span style={styles.balanceLabel}>Balance Due</span>
            <span style={{ ...styles.balanceAmount, color: balance <= 0 ? '#38a169' : '#e53e3e' }}>
              ₦{balance.toLocaleString()}
            </span>
          </div>

          {/* Payment history */}
          {credit?.payments?.length > 0 && (
            <>
              <div style={{ ...styles.divider, marginTop: '24px' }} />
              <p style={styles.historyTitle}>Payment History</p>
              {credit.payments.map(p => (
                <div key={p.id} style={styles.historyRow}>
                  <span style={styles.historyDate}>{new Date(p.paid_at).toLocaleDateString('en-NG')}</span>
                  <span style={styles.historyAmt}>₦{p.amount.toLocaleString()}</span>
                </div>
              ))}
            </>
          )}

          {/* Acknowledgement line */}
          <div style={styles.acknowledgement}>
            <p style={styles.acknowledgementText}>
              Both parties acknowledge the accuracy of this invoice.
            </p>
          </div>

          {/* Footer */}
          <div style={styles.invoiceFooter}>
            <p style={styles.footerText}>Thank you for your business 🙏</p>
            <p style={styles.footerShop}>{shopName}{ownerName ? ` · ${ownerName}` : ''}</p>
          </div>
        </div>

        {/* Share actions */}
        <div style={styles.actions} className="no-print">
          <button onClick={handleWhatsApp} style={styles.whatsappBtn}>📲 WhatsApp</button>
          <button onClick={handlePrint} style={styles.printBtn}>🖨️ Print</button>
          <button onClick={handleDownload} style={styles.downloadBtn}>📥 Download</button>
          <button onClick={handleEmail} style={styles.emailBtn}>✉️ Email</button>
        </div>

        <p style={styles.printNote} className="no-print">
          🖨️ Mini Bluetooth printers work — tap Print and select your printer.
        </p>
      </div>
    </>
  )
}

const styles = {
  container: { maxWidth: '480px', margin: '0 auto', padding: '20px', minHeight: '100vh', backgroundColor: '#f0f4f8' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', paddingTop: '10px' },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },
  invoiceCard: { backgroundColor: '#ffffff', borderRadius: '16px', padding: '28px 24px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)', marginBottom: '16px' },
  invoiceHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' },
  shopName: { fontSize: '22px', fontWeight: '800', color: '#1a1a2e', marginBottom: '2px' },
  ownerName: { fontSize: '13px', color: '#888' },
  invMeta: { textAlign: 'right' },
  invLabel: { fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px' },
  invNumber: { fontSize: '16px', fontWeight: '700', color: '#1a1a2e' },
  invDate: { fontSize: '12px', color: '#888', marginTop: '2px' },
  divider: { border: 'none', borderTop: '1.5px solid #f0f0f0', margin: '0 0 20px 0' },
  billedTo: { marginBottom: '20px' },
  billedLabel: { fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '6px' },
  billedName: { fontSize: '17px', fontWeight: '700', color: '#1a1a2e', marginBottom: '2px' },
  billedSub: { fontSize: '13px', color: '#888', marginTop: '2px' },

  // Items box — NEW
  itemsBox: {
    backgroundColor: '#f8f9fa',
    borderRadius: '10px',
    padding: '14px 16px',
    marginBottom: '16px',
    borderLeft: '4px solid #1a1a2e',
  },
  itemsLabel: { fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' },
  itemText: { fontSize: '15px', fontWeight: '700', color: '#1a1a2e', marginBottom: '4px' },
  notesText: { fontSize: '13px', color: '#555', lineHeight: '1.5' },
  noPaymentNote: { fontSize: '12px', color: '#e53e3e', fontStyle: 'italic' },

  amountRows: { marginBottom: '16px' },
  amountRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f8f8f8' },
  amountLabel: { fontSize: '14px', color: '#888' },
  amountValue: { fontSize: '14px', fontWeight: '600', color: '#1a1a2e' },
  statusBadge: { fontSize: '11px', fontWeight: '700', padding: '4px 10px', borderRadius: '20px', letterSpacing: '0.3px' },
  balanceRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '2px solid #1a1a2e', paddingTop: '16px', marginTop: '8px' },
  balanceLabel: { fontSize: '16px', fontWeight: '700', color: '#1a1a2e' },
  balanceAmount: { fontSize: '24px', fontWeight: '800' },
  historyTitle: { fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '10px', marginTop: '4px' },
  historyRow: { display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid #f0f0f0' },
  historyDate: { fontSize: '13px', color: '#888' },
  historyAmt: { fontSize: '13px', fontWeight: '700', color: '#38a169' },

  // Acknowledgement
  acknowledgement: { marginTop: '20px', paddingTop: '16px', borderTop: '1px dashed #e0e0e0', textAlign: 'center' },
  acknowledgementText: { fontSize: '11px', color: '#aaa', fontStyle: 'italic' },

  invoiceFooter: { marginTop: '20px', textAlign: 'center', borderTop: '1px solid #f0f0f0', paddingTop: '16px' },
  footerText: { fontSize: '13px', color: '#888', marginBottom: '4px' },
  footerShop: { fontSize: '12px', color: '#aaa' },
  actions: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '12px' },
  whatsappBtn: { padding: '14px', backgroundColor: '#25D366', color: '#ffffff', border: 'none', borderRadius: '12px', fontSize: '15px', fontWeight: '600', cursor: 'pointer' },
  printBtn: { padding: '14px', backgroundColor: '#1a1a2e', color: '#ffffff', border: 'none', borderRadius: '12px', fontSize: '15px', fontWeight: '600', cursor: 'pointer' },
  downloadBtn: { padding: '14px', backgroundColor: '#4a90e2', color: '#ffffff', border: 'none', borderRadius: '12px', fontSize: '15px', fontWeight: '600', cursor: 'pointer' },
  emailBtn: { padding: '14px', backgroundColor: '#ffffff', color: '#1a1a2e', border: '1.5px solid #1a1a2e', borderRadius: '12px', fontSize: '15px', fontWeight: '600', cursor: 'pointer' },
  printNote: { fontSize: '12px', color: '#aaa', textAlign: 'center', lineHeight: '1.5', padding: '0 10px' },
  loading: { display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', fontSize: '16px', color: '#888' },
}

export default Invoice

