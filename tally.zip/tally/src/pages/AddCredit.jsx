import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'

function AddCredit() {
  const [credits, setCredits] = useState([])
  const [payments, setPayments] = useState({})
  const [customer, setCustomer] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [shopName, setShopName] = useState('')

  // Edit customer modal
  const [editingCustomer, setEditingCustomer] = useState(false)
  const [editName, setEditName] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editAddress, setEditAddress] = useState('')
  const [editNotes, setEditNotes] = useState('')
  const [editWishlist, setEditWishlist] = useState('')
  const [editGuarantorName, setEditGuarantorName] = useState('')
  const [editGuarantorPhone, setEditGuarantorPhone] = useState('')

  // New credit form
  const [amount, setAmount] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [notes, setNotes] = useState('')
  const [itemDescription, setItemDescription] = useState('')

  // Payment input per credit
  const [paymentInputs, setPaymentInputs] = useState({})

  // Edit credit per credit
  const [editingCreditId, setEditingCreditId] = useState(null)
  const [editCreditAmount, setEditCreditAmount] = useState('')
  const [editCreditDueDate, setEditCreditDueDate] = useState('')
  const [editCreditNotes, setEditCreditNotes] = useState('')
  const [editCreditItem, setEditCreditItem] = useState('')

  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const customerId = searchParams.get('customerId')
  const customerName = searchParams.get('customerName')
  const today = new Date().toISOString().split('T')[0]

  useEffect(() => {
    if (customerId) {
      fetchCredits()
      fetchCustomer()
    }
    getShopName()
  }, [customerId])

  const getShopName = async () => {
    const { data } = await supabase.auth.getUser()
    setShopName(data.user?.user_metadata?.shop_name || 'Our Shop')
  }

  const fetchCustomer = async () => {
    const { data } = await supabase
      .from('customers')
      .select('*')
      .eq('id', customerId)
      .single()
    if (data) {
      setCustomer(data)
      setEditName(data.full_name || '')
      setEditPhone(data.phone || '')
      setEditAddress(data.address || '')
      setEditNotes(data.notes || '')
      setEditWishlist(data.wishlist || '')
      setEditGuarantorName(data.guarantor_name || '')
      setEditGuarantorPhone(data.guarantor_phone || '')
    }
  }

  const fetchCredits = async () => {
    const { data } = await supabase
      .from('credits')
      .select('*, payments(*), customers(phone)')
      .eq('customer_id', customerId)
      .eq('status', 'unpaid')
      .order('created_at', { ascending: false })
    if (data) {
      setCredits(data)
      const pm = {}
      data.forEach(c => { pm[c.id] = c.payments || [] })
      setPayments(pm)
    }
  }

  // ── Save customer edits ──
  const saveCustomerEdit = async () => {
    setLoading(true)
    const { error } = await supabase
      .from('customers')
      .update({
        full_name: editName.trim(),
        phone: editPhone.trim(),
        address: editAddress.trim(),
        notes: editNotes.trim(),
        wishlist: editWishlist.trim(),
        guarantor_name: editGuarantorName.trim(),
        guarantor_phone: editGuarantorPhone.trim(),
      })
      .eq('id', customerId)
    if (!error) {
      setEditingCustomer(false)
      fetchCustomer()
    }
    setLoading(false)
  }

  // ── Delete customer ──
  const deleteCustomer = async () => {
    if (!window.confirm(`Delete ${customer?.full_name} and all their records permanently? This cannot be undone.`)) return
    setLoading(true)
    // Delete payments first, then credits, then customer
    for (const credit of credits) {
      await supabase.from('payments').delete().eq('credit_id', credit.id)
    }
    await supabase.from('credits').delete().eq('customer_id', customerId)
    await supabase.from('customers').delete().eq('id', customerId)
    navigate('/customers')
  }

  // ── Add new credit ──
  const handleAddCredit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error } = await supabase.from('credits').insert({
      customer_id: customerId,
      amount: parseFloat(amount),
      due_date: dueDate || null,
      notes: itemDescription ? `${itemDescription}${notes ? ' — ' + notes : ''}` : (notes || null),
      status: 'unpaid',
    })
    if (error) { setError(error.message) } else {
      setAmount(''); setDueDate(''); setNotes(''); setItemDescription('')
      fetchCredits()
    }
    setLoading(false)
  }

  // ── Record payment ──
  const handleAddPayment = async (credit) => {
    const pAmt = parseFloat(paymentInputs[credit.id] || 0)
    if (!pAmt) return
    setLoading(true)
    const newPaid = credit.amount_paid + pAmt
    const fullyPaid = newPaid >= credit.amount
    await supabase.from('payments').insert({ credit_id: credit.id, amount: pAmt })
    await supabase.from('credits').update({
      amount_paid: newPaid,
      status: fullyPaid ? 'paid' : 'unpaid',
    }).eq('id', credit.id)
    setPaymentInputs(prev => ({ ...prev, [credit.id]: '' }))
    fetchCredits()
    setLoading(false)
  }

  // ── Delete credit ──
  const deleteCredit = async (credit) => {
    if (!window.confirm('Delete this credit and all its payment records? This cannot be undone.')) return
    setLoading(true)
    await supabase.from('payments').delete().eq('credit_id', credit.id)
    await supabase.from('credits').delete().eq('id', credit.id)
    fetchCredits()
    setLoading(false)
  }

  // ── Mark responded ──
  const handleMarkResponded = async (creditId) => {
    await supabase.from('credits').update({ customer_responded: true }).eq('id', creditId)
    fetchCredits()
  }

  // ── Save credit edit ──
  const saveCreditEdit = async (credit) => {
    await supabase.from('credits').update({
      amount: parseFloat(editCreditAmount),
      due_date: editCreditDueDate || null,
      notes: editCreditItem ? `${editCreditItem}${editCreditNotes ? ' — ' + editCreditNotes : ''}` : (editCreditNotes || null),
    }).eq('id', credit.id)
    setEditingCreditId(null)
    fetchCredits()
  }

  const startCreditEdit = (credit) => {
    setEditingCreditId(credit.id)
    setEditCreditAmount(credit.amount)
    setEditCreditDueDate(credit.due_date || '')
    // Try to split notes back into item + note
    const parts = (credit.notes || '').split(' — ')
    setEditCreditItem(parts[0] || '')
    setEditCreditNotes(parts[1] || '')
  }

  // ── WhatsApp message ──
  const buildMessage = (credit) => {
    const balance = credit.amount - credit.amount_paid
    return `Hello ${customer?.full_name || customerName}, this is a reminder from *${shopName}*. You have an outstanding balance of ₦${balance.toLocaleString()}${credit.due_date ? ` due on ${credit.due_date}` : ''}. Please make payment. Thank you.`
  }

  const phoneNumber = customer?.phone || ''
  const whatsappPhone = phoneNumber.replace(/^0/, '234')
  const callLink = phoneNumber ? `tel:${phoneNumber}` : null
  const whatsappChatLink = whatsappPhone ? `https://wa.me/${whatsappPhone}` : null

  const totalBalance = credits.reduce((s, c) => s + (c.amount - c.amount_paid), 0)
  const totalOwed = credits.reduce((s, c) => s + c.amount, 0)
  const totalPaid = credits.reduce((s, c) => s + c.amount_paid, 0)

  const dueBadge = (credit) => {
    if (!credit.due_date) return null
    const diff = Math.ceil((new Date(credit.due_date) - new Date(today)) / (1000 * 60 * 60 * 24))
    if (diff < 0) return { label: 'Overdue', bg: '#fff0f0', color: '#e53e3e' }
    if (diff <= 3) return { label: `Due in ${diff}d`, bg: '#fffbeb', color: '#d97706' }
    return { label: `Due ${credit.due_date}`, bg: '#f0fff4', color: '#38a169' }
  }

  const displayName = customer?.full_name || customerName

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <Link to="/customers" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title} numberOfLines={1}>{displayName}</h2>
        <div style={styles.headerActions}>
          <button onClick={() => setEditingCustomer(true)} style={styles.editCustomerBtn}>✏️ Edit</button>
        </div>
      </div>

      {error && <div style={styles.error}>{error}</div>}

      {/* ── Quick contact bar ── */}
      {phoneNumber && (
        <div style={styles.contactBar}>
          <a href={callLink} style={styles.contactBtn}>
            📞 Call
          </a>
          <a href={whatsappChatLink} target="_blank" rel="noreferrer" style={{ ...styles.contactBtn, backgroundColor: '#25D366' }}>
            💬 WhatsApp Chat
          </a>
          <a href={`sms:${phoneNumber}`} style={{ ...styles.contactBtn, backgroundColor: '#4a90e2' }}>
            ✉️ SMS
          </a>
        </div>
      )}

      {/* ── Customer info card ── */}
      {customer && (
        <div style={styles.customerCard}>
          <div style={styles.customerCardRow}>
            <div style={styles.bigAvatar}>{displayName.charAt(0).toUpperCase()}</div>
            <div style={styles.customerDetails}>
              <p style={styles.customerFullName}>{displayName}</p>
              {customer.phone && <p style={styles.customerMeta}>📱 {customer.phone}</p>}
              {customer.address && <p style={styles.customerMeta}>📍 {customer.address}</p>}
              {customer.notes && <p style={styles.customerMeta}>📝 {customer.notes}</p>}
              {customer.wishlist && (
                <p style={styles.wishlistText}>🛍️ Wishlist: {customer.wishlist}</p>
              )}
              {customer.guarantor_name && (
                <p style={styles.customerMeta}>👤 Guarantor: {customer.guarantor_name} {customer.guarantor_phone ? `· ${customer.guarantor_phone}` : ''}</p>
              )}
            </div>
          </div>
          <button onClick={deleteCustomer} style={styles.deleteCustomerBtn}>
            🗑️ Delete Customer
          </button>
        </div>
      )}

      {/* ── Edit Customer Modal ── */}
      {editingCustomer && (
        <div style={styles.modalOverlay}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <p style={styles.modalTitle}>Edit Customer</p>
              <button onClick={() => setEditingCustomer(false)} style={styles.modalClose}>✕</button>
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Full Name</label>
              <input value={editName} onChange={e => setEditName(e.target.value)} style={styles.input} placeholder="Full name" />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Phone Number</label>
              <input value={editPhone} onChange={e => setEditPhone(e.target.value)} style={styles.input} placeholder="08012345678" type="tel" />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Address</label>
              <input value={editAddress} onChange={e => setEditAddress(e.target.value)} style={styles.input} placeholder="Address" />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Notes</label>
              <input value={editNotes} onChange={e => setEditNotes(e.target.value)} style={styles.input} placeholder="Any notes about this customer" />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>🛍️ Wishlist / Needs</label>
              <input value={editWishlist} onChange={e => setEditWishlist(e.target.value)} style={styles.input} placeholder="e.g. red handbag, ankara fabric" />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Guarantor Name</label>
              <input value={editGuarantorName} onChange={e => setEditGuarantorName(e.target.value)} style={styles.input} placeholder="Guarantor name" />
            </div>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Guarantor Phone</label>
              <input value={editGuarantorPhone} onChange={e => setEditGuarantorPhone(e.target.value)} style={styles.input} placeholder="Guarantor phone" type="tel" />
            </div>

            <div style={styles.modalBtns}>
              <button onClick={saveCustomerEdit} style={styles.saveBtn} disabled={loading}>
                {loading ? 'Saving...' : 'Save Changes'}
              </button>
              <button onClick={() => setEditingCustomer(false)} style={styles.cancelBtn}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Summary card ── */}
      {credits.length > 0 && (
        <div style={styles.summaryCard}>
          <p style={styles.summaryLabel}>Total Outstanding</p>
          <p style={styles.summaryAmount}>₦{totalBalance.toLocaleString()}</p>
          <div style={styles.summaryRow}>
            <span style={styles.summaryMeta}>Owed: ₦{totalOwed.toLocaleString()}</span>
            <span style={styles.summaryMeta}>Paid: ₦{totalPaid.toLocaleString()}</span>
            <span style={styles.summaryMeta}>{credits.length} credit{credits.length > 1 ? 's' : ''}</span>
          </div>
          <button
            onClick={() => navigate(`/invoice?creditId=${credits[0].id}&customerId=${customerId}&customerName=${encodeURIComponent(displayName)}`)}
            style={styles.invoiceBtn}
          >
            🧾 Generate Invoice
          </button>
        </div>
      )}

      {/* ── Each credit ── */}
      {credits.map(credit => {
        const balance = credit.amount - credit.amount_paid
        const badge = dueBadge(credit)
        const isEditing = editingCreditId === credit.id
        const pct = Math.min(100, Math.round((credit.amount_paid / credit.amount) * 100))

        return (
          <div key={credit.id} style={styles.creditBlock}>
            {isEditing ? (
              <div style={styles.editSection}>
                <p style={styles.sectionTitle}>Edit Credit</p>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>What was bought?</label>
                  <input value={editCreditItem} onChange={e => setEditCreditItem(e.target.value)} style={styles.input} placeholder="e.g. 3 bags of rice, fabric, shoes" />
                </div>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Amount (₦)</label>
                  <input type="number" value={editCreditAmount} onChange={e => setEditCreditAmount(e.target.value)} style={styles.input} />
                </div>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Due Date</label>
                  <input type="date" value={editCreditDueDate} onChange={e => setEditCreditDueDate(e.target.value)} style={styles.input} />
                </div>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Extra Notes</label>
                  <input value={editCreditNotes} onChange={e => setEditCreditNotes(e.target.value)} style={styles.input} placeholder="Optional" />
                </div>
                <div style={styles.editBtns}>
                  <button onClick={() => saveCreditEdit(credit)} style={styles.saveBtn}>Save</button>
                  <button onClick={() => setEditingCreditId(null)} style={styles.cancelBtn}>Cancel</button>
                </div>
              </div>
            ) : (
              <>
                {/* Badge + action row */}
                <div style={styles.creditTopRow}>
                  {badge && (
                    <span style={{ ...styles.badge, backgroundColor: badge.bg, color: badge.color }}>
                      {badge.label}
                    </span>
                  )}
                  <div style={styles.creditActions}>
                    <button onClick={() => startCreditEdit(credit)} style={styles.editBtn}>✏️ Edit</button>
                    <button onClick={() => deleteCredit(credit)} style={styles.deleteCreditBtn}>🗑️ Delete</button>
                  </div>
                </div>

                {/* Balance */}
                <div style={styles.balanceRow}>
                  <div>
                    <p style={styles.balanceLabel}>Balance</p>
                    <p style={styles.balanceAmt}>₦{balance.toLocaleString()}</p>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <p style={styles.balanceMeta}>of ₦{credit.amount.toLocaleString()}</p>
                    <p style={{ ...styles.balanceMeta, color: '#38a169' }}>₦{credit.amount_paid.toLocaleString()} paid</p>
                  </div>
                </div>

                {/* Progress */}
                <div style={styles.progressWrap}>
                  <div style={{ ...styles.progressFill, width: `${pct}%` }} />
                </div>
                <p style={styles.progressPct}>{pct}% paid</p>

                {/* Item description */}
                {credit.notes && (
                  <p style={styles.creditNotes}>📦 {credit.notes}</p>
                )}

                {/* Invoice for this credit */}
                <button
                  onClick={() => navigate(`/invoice?creditId=${credit.id}&customerId=${customerId}&customerName=${encodeURIComponent(displayName)}`)}
                  style={styles.invoiceSmallBtn}
                >
                  🧾 Invoice
                </button>

                {/* WhatsApp reminder */}
                <a
                  href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent(buildMessage(credit))}`}
                  target="_blank"
                  rel="noreferrer"
                  style={styles.whatsappBtn}
                >
                  📲 Send Payment Reminder
                </a>

                {/* Mark responded */}
                <div style={styles.respondSection}>
                  {credit.customer_responded ? (
                    <p style={styles.respondedText}>✅ Customer has responded</p>
                  ) : (
                    <button onClick={() => handleMarkResponded(credit.id)} style={styles.respondBtn}>
                      Mark as Responded
                    </button>
                  )}
                </div>

                {/* Record payment */}
                <div style={styles.paymentRow}>
                  <input
                    type="number"
                    value={paymentInputs[credit.id] || ''}
                    onChange={e => setPaymentInputs(prev => ({ ...prev, [credit.id]: e.target.value }))}
                    placeholder="Amount paid"
                    style={styles.paymentInput}
                  />
                  <button onClick={() => handleAddPayment(credit)} style={styles.payBtn} disabled={loading}>
                    Record
                  </button>
                </div>

                {/* Payment history */}
                {payments[credit.id]?.length > 0 && (
                  <div style={styles.historySection}>
                    <p style={styles.historyTitle}>Payment History</p>
                    {payments[credit.id].map(p => (
                      <div key={p.id} style={styles.historyRow}>
                        <span style={styles.historyDate}>{new Date(p.paid_at).toLocaleDateString('en-NG')}</span>
                        <span style={styles.historyAmt}>₦{p.amount.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )
      })}

      {/* ── Add New Credit ── */}
      <div style={styles.addSection}>
        <p style={styles.sectionTitle}>Add New Credit</p>
        <form onSubmit={handleAddCredit} style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>What did they buy? *</label>
            <input
              type="text"
              value={itemDescription}
              onChange={e => setItemDescription(e.target.value)}
              placeholder="e.g. 3 bags of rice, ankara fabric, shoes..."
              style={styles.input}
              required
            />
          </div>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Amount Owed (₦) *</label>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="e.g. 50000"
              style={styles.input}
              required
            />
          </div>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Due Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
              style={styles.input}
            />
          </div>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Extra Notes (optional)</label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Any extra details"
              style={styles.input}
            />
          </div>
          <button type="submit" style={loading ? styles.buttonDisabled : styles.button} disabled={loading}>
            {loading ? 'Saving...' : 'Add Credit'}
          </button>
        </form>
      </div>
    </div>
  )
}

const styles = {
  container: { maxWidth: '480px', margin: '0 auto', padding: '20px', minHeight: '100vh', backgroundColor: '#f0f4f8' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', paddingTop: '10px' },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '16px', fontWeight: '700', color: '#1a1a2e', flex: 1, textAlign: 'center', margin: '0 8px' },
  headerActions: { display: 'flex', gap: '6px' },
  editCustomerBtn: { padding: '6px 12px', backgroundColor: '#f0f4f8', border: '1.5px solid #e0e0e0', borderRadius: '8px', fontSize: '13px', cursor: 'pointer', color: '#1a1a2e', fontWeight: '600' },

  // Contact bar
  contactBar: { display: 'flex', gap: '8px', marginBottom: '14px' },
  contactBtn: { flex: 1, padding: '10px 6px', backgroundColor: '#1a1a2e', color: '#fff', borderRadius: '10px', textDecoration: 'none', fontWeight: '600', fontSize: '13px', textAlign: 'center' },

  // Customer card
  customerCard: { backgroundColor: '#fff', borderRadius: '16px', padding: '16px', marginBottom: '14px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  customerCardRow: { display: 'flex', gap: '14px', marginBottom: '14px' },
  bigAvatar: { width: '52px', height: '52px', borderRadius: '50%', backgroundColor: '#1a1a2e', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontWeight: '800', flexShrink: 0 },
  customerDetails: { flex: 1 },
  customerFullName: { fontSize: '17px', fontWeight: '800', color: '#1a1a2e', marginBottom: '4px' },
  customerMeta: { fontSize: '13px', color: '#666', marginBottom: '2px', lineHeight: '1.4' },
  wishlistText: { fontSize: '13px', color: '#4a90e2', marginTop: '4px', fontWeight: '600' },
  deleteCustomerBtn: { width: '100%', padding: '10px', backgroundColor: '#fff0f0', color: '#e53e3e', border: '1.5px solid #e53e3e', borderRadius: '10px', fontSize: '13px', fontWeight: '700', cursor: 'pointer' },

  // Modal
  modalOverlay: { position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 500, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' },
  modal: { backgroundColor: '#fff', borderRadius: '24px 24px 0 0', padding: '24px', width: '100%', maxWidth: '480px', maxHeight: '85vh', overflowY: 'auto' },
  modalHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' },
  modalTitle: { fontSize: '18px', fontWeight: '800', color: '#1a1a2e' },
  modalClose: { background: '#f0f4f8', border: 'none', borderRadius: '50%', width: '32px', height: '32px', fontSize: '14px', cursor: 'pointer' },
  modalBtns: { display: 'flex', gap: '10px', marginTop: '16px' },

  // Summary card
  summaryCard: { backgroundColor: '#1a1a2e', borderRadius: '16px', padding: '24px', marginBottom: '16px', textAlign: 'center' },
  summaryLabel: { color: '#aaa', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '6px' },
  summaryAmount: { color: '#fff', fontSize: '36px', fontWeight: '800', marginBottom: '10px' },
  summaryRow: { display: 'flex', justifyContent: 'center', gap: '16px', marginBottom: '16px' },
  summaryMeta: { color: '#888', fontSize: '12px' },
  invoiceBtn: { width: '100%', padding: '12px', backgroundColor: '#fff', color: '#1a1a2e', border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '700', cursor: 'pointer' },

  // Credit block
  creditBlock: { backgroundColor: '#fff', borderRadius: '16px', padding: '20px', marginBottom: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  creditTopRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' },
  badge: { fontSize: '12px', fontWeight: '700', padding: '4px 10px', borderRadius: '20px' },
  creditActions: { display: 'flex', gap: '6px' },
  editBtn: { background: 'none', border: '1.5px solid #e0e0e0', borderRadius: '8px', padding: '5px 10px', fontSize: '12px', cursor: 'pointer', color: '#888' },
  deleteCreditBtn: { background: 'none', border: '1.5px solid #e53e3e', borderRadius: '8px', padding: '5px 10px', fontSize: '12px', cursor: 'pointer', color: '#e53e3e' },

  balanceRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '10px' },
  balanceLabel: { fontSize: '12px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' },
  balanceAmt: { fontSize: '28px', fontWeight: '800', color: '#1a1a2e' },
  balanceMeta: { fontSize: '12px', color: '#888' },
  progressWrap: { height: '6px', backgroundColor: '#f0f0f0', borderRadius: '3px', overflow: 'hidden', marginBottom: '4px' },
  progressFill: { height: '100%', backgroundColor: '#38a169', borderRadius: '3px', transition: 'width 0.4s ease' },
  progressPct: { fontSize: '11px', color: '#888', marginBottom: '10px' },
  creditNotes: { fontSize: '13px', color: '#666', fontStyle: 'italic', marginBottom: '12px', padding: '8px 12px', backgroundColor: '#f8f9fa', borderRadius: '8px' },

  invoiceSmallBtn: { width: '100%', padding: '10px', backgroundColor: '#f0f4f8', color: '#1a1a2e', border: '1.5px solid #e0e0e0', borderRadius: '10px', fontSize: '14px', fontWeight: '600', cursor: 'pointer', marginBottom: '10px' },
  whatsappBtn: { display: 'block', padding: '12px', backgroundColor: '#25D366', color: '#fff', borderRadius: '10px', textDecoration: 'none', fontWeight: '600', fontSize: '14px', textAlign: 'center', marginBottom: '10px' },

  respondSection: { marginBottom: '12px' },
  respondedText: { color: '#38a169', fontWeight: '600', fontSize: '14px' },
  respondBtn: { width: '100%', padding: '10px', backgroundColor: '#f0f4f8', color: '#1a1a2e', border: '1.5px solid #1a1a2e', borderRadius: '10px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' },

  paymentRow: { display: 'flex', gap: '10px', marginBottom: '8px' },
  paymentInput: { flex: 1, padding: '12px 16px', borderRadius: '10px', border: '1.5px solid #e0e0e0', fontSize: '15px', outline: 'none' },
  payBtn: { padding: '12px 20px', backgroundColor: '#38a169', color: '#fff', border: 'none', borderRadius: '10px', fontSize: '15px', fontWeight: '600', cursor: 'pointer' },

  historySection: { borderTop: '1px solid #f0f0f0', paddingTop: '12px', marginTop: '4px' },
  historyTitle: { fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' },
  historyRow: { display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f8f8f8' },
  historyDate: { fontSize: '13px', color: '#888' },
  historyAmt: { fontSize: '13px', fontWeight: '700', color: '#38a169' },

  // Edit credit form
  editSection: { display: 'flex', flexDirection: 'column', gap: '14px' },

  // Add credit
  addSection: { backgroundColor: '#fff', borderRadius: '16px', padding: '20px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  sectionTitle: { fontSize: '13px', fontWeight: '700', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '14px' },
  form: { display: 'flex', flexDirection: 'column', gap: '14px' },
  inputGroup: { display: 'flex', flexDirection: 'column', gap: '6px' },
  label: { fontSize: '14px', fontWeight: '600', color: '#1a1a2e' },
  input: { padding: '12px 16px', borderRadius: '10px', border: '1.5px solid #e0e0e0', fontSize: '15px', outline: 'none' },
  button: { padding: '14px', backgroundColor: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '10px', fontSize: '16px', fontWeight: '600', cursor: 'pointer' },
  buttonDisabled: { padding: '14px', backgroundColor: '#888', color: '#fff', border: 'none', borderRadius: '10px', fontSize: '16px', fontWeight: '600', cursor: 'not-allowed' },
  saveBtn: { flex: 1, padding: '12px', backgroundColor: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' },
  cancelBtn: { flex: 1, padding: '12px', backgroundColor: '#f0f4f8', color: '#888', border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' },

  error: { backgroundColor: '#fff0f0', color: '#e53e3e', padding: '12px', borderRadius: '8px', fontSize: '14px', marginBottom: '16px', textAlign: 'center' },
}

export default AddCredit
