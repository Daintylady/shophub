import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'

function ProSuccess() {
  const [plan, setPlan] = useState('monthly')
  const [expiryDisplay, setExpiryDisplay] = useState('')
  const [activated, setActivated] = useState(false)

  useEffect(() => {
    activate()
  }, [])

  const activate = async () => {
    // Read plan that was saved in ProUpgrade onSuccess BEFORE the redirect
    let selectedPlan = 'monthly'
    let ref = ''

    try {
      selectedPlan = localStorage.getItem('tally_pro_plan') || 'monthly'
      ref = localStorage.getItem('tally_pro_ref') || ''
    } catch (e) {}

    setPlan(selectedPlan)

    // If pro_expiry is already written (ProUpgrade wrote it before redirecting), use it.
    // Otherwise write it now as a fallback.
    let expiryStr = ''
    try {
      expiryStr = localStorage.getItem('tally_pro_expiry') || ''
    } catch (e) {}

    if (!expiryStr || new Date(expiryStr) <= new Date()) {
      // Fallback: calculate and write now
      const months = selectedPlan === 'yearly' ? 12 : 1
      const expiry = new Date()
      expiry.setMonth(expiry.getMonth() + months)
      expiryStr = expiry.toISOString()

      try {
        localStorage.setItem('tally_pro_expiry', expiryStr)
        localStorage.setItem('tally_pro_plan', selectedPlan)
      } catch (e) {}
    }

    // Show the expiry date to the user
    try {
      setExpiryDisplay(
        new Date(expiryStr).toLocaleDateString('en-NG', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })
      )
    } catch (e) {}

    // Sync to Supabase in background — don't block the UI
    supabase.auth.updateUser({
      data: {
        pro_expiry: expiryStr,
        pro_plan: selectedPlan,
        pro_ref: ref,
      },
    }).catch(() => {})

    setActivated(true)
  }

  return (
    <div style={styles.container}>
      <div style={styles.card}>

        <div style={styles.crownCircle}>👑</div>
        <p style={styles.confetti}>🎉🎉🎉</p>

        <h1 style={styles.title}>Welcome to Tally Pro!</h1>
        <p style={styles.sub}>
          Your {plan === 'yearly' ? 'yearly' : 'monthly'} subscription is now active.
          Every Pro feature is unlocked for your shop.
        </p>

        {expiryDisplay ? (
          <div style={styles.expiryBadge}>
            <p style={styles.expiryText}>✅ Pro active until {expiryDisplay}</p>
          </div>
        ) : null}

        <div style={styles.featureGrid}>
          {[
            '🧾 Unlimited Invoices',
            '📊 Full Analytics',
            '💸 Expense Tracking',
            '📦 Inventory',
            '⏰ Auto Reminders',
            '📄 PDF Export',
            '👥 Multi-Staff',
            '🔒 Data Backup',
          ].map((f, i) => (
            <div key={i} style={styles.featureChip}>{f}</div>
          ))}
        </div>

        <Link to="/dashboard" style={styles.btn}>
          Go to Dashboard →
        </Link>

        <p style={styles.note}>
          Your Pro access is saved. Even if you log out and back in, it stays active until your subscription expires.
        </p>
      </div>
    </div>
  )
}

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f0f4f8',
    padding: '20px',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: '20px',
    padding: '40px 28px',
    maxWidth: '420px',
    width: '100%',
    textAlign: 'center',
    boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
  },
  crownCircle: {
    width: '80px',
    height: '80px',
    borderRadius: '50%',
    backgroundColor: '#fef3c7',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '36px',
    margin: '0 auto 8px',
  },
  confetti: { fontSize: '28px', marginBottom: '16px' },
  title: { fontSize: '26px', fontWeight: '800', color: '#1a1a2e', marginBottom: '12px' },
  sub: { fontSize: '15px', color: '#666', lineHeight: '1.6', marginBottom: '20px' },
  expiryBadge: {
    backgroundColor: '#f0fff4',
    border: '1.5px solid #38a169',
    borderRadius: '10px',
    padding: '10px 16px',
    marginBottom: '20px',
  },
  expiryText: { color: '#276749', fontWeight: '700', fontSize: '14px' },
  featureGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '10px',
    marginBottom: '28px',
  },
  featureChip: {
    backgroundColor: '#f0fff4',
    color: '#276749',
    borderRadius: '10px',
    padding: '10px 8px',
    fontSize: '13px',
    fontWeight: '600',
  },
  btn: {
    display: 'block',
    padding: '16px',
    backgroundColor: '#1a1a2e',
    color: '#ffffff',
    borderRadius: '12px',
    textDecoration: 'none',
    fontWeight: '700',
    fontSize: '16px',
    marginBottom: '16px',
  },
  note: { fontSize: '12px', color: '#aaa', lineHeight: '1.5' },
}

export default ProSuccess
