import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, Link } from 'react-router-dom'

// ─── Mini bar chart (pure CSS, no library needed) ───────────────────────────
function BarChart({ data, color = '#1a1a2e', valuePrefix = '₦' }) {
  if (!data || data.length === 0) return null
  const max = Math.max(...data.map(d => d.value), 1)
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: '6px', height: '80px' }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
          <div
            style={{
              width: '100%',
              height: `${Math.max(4, Math.round((d.value / max) * 70))}px`,
              backgroundColor: color,
              borderRadius: '4px 4px 0 0',
              transition: 'height 0.5s ease',
              opacity: i === data.length - 1 ? 1 : 0.5 + (i / data.length) * 0.5,
            }}
          />
          <span style={{ fontSize: '9px', color: '#aaa', textAlign: 'center', lineHeight: 1.2 }}>{d.label}</span>
        </div>
      ))}
    </div>
  )
}

// ─── Donut ring (pure SVG) ───────────────────────────────────────────────────
function DonutRing({ pct, color, size = 80 }) {
  const r = 28
  const circ = 2 * Math.PI * r
  const fill = (pct / 100) * circ
  return (
    <svg width={size} height={size} viewBox="0 0 64 64">
      <circle cx="32" cy="32" r={r} fill="none" stroke="#f0f0f0" strokeWidth="8" />
      <circle
        cx="32" cy="32" r={r} fill="none"
        stroke={color} strokeWidth="8"
        strokeDasharray={`${fill} ${circ}`}
        strokeLinecap="round"
        transform="rotate(-90 32 32)"
      />
      <text x="32" y="36" textAnchor="middle" fontSize="13" fontWeight="800" fill="#1a1a2e">
        {pct}%
      </text>
    </svg>
  )
}

// ─── Horizontal bar (for rankings) ──────────────────────────────────────────
function HBar({ pct, color }) {
  return (
    <div style={{ height: '6px', backgroundColor: '#f0f0f0', borderRadius: '3px', overflow: 'hidden', flex: 1 }}>
      <div style={{ height: '100%', width: `${pct}%`, backgroundColor: color, borderRadius: '3px', transition: 'width 0.6s ease' }} />
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
function Analytics() {
  const [loading, setLoading] = useState(true)
  const [shopName, setShopName] = useState('')
  const [tab, setTab] = useState('overview') // overview | customers | products | trends

  // Overview stats
  const [stats, setStats] = useState({
    totalOwed: 0, totalCustomers: 0, overdueCount: 0,
    paidThisMonth: 0, paidLastMonth: 0, totalEverCollected: 0,
    totalEverIssued: 0, creditCount: 0,
  })

  // Top debtors
  const [topDebtors, setTopDebtors] = useState([])

  // Best payers (paid most total)
  const [bestPayers, setBestPayers] = useState([])

  // Overdue list
  const [overdueList, setOverdueList] = useState([])

  // Monthly trend (last 6 months)
  const [monthlyTrend, setMonthlyTrend] = useState([])

  // Most wanted products (from wishlist)
  const [topProducts, setTopProducts] = useState([])

  // Credit vs full payment split
  const [paymentSplit, setPaymentSplit] = useState({ partialPct: 0, fullPct: 0 })

  const navigate = useNavigate()

  useEffect(() => { loadAll() }, [])

  const loadAll = async () => {
    const { data: userData } = await supabase.auth.getUser()
    setShopName(userData.user?.user_metadata?.shop_name || 'Your Shop')

    const today = new Date()
    const todayStr = today.toISOString().split('T')[0]

    // ── All credits (unpaid + paid) ──
    const { data: allCredits } = await supabase
      .from('credits')
      .select('*, customers(id, full_name, phone, wishlist)')

    // ── All payments ──
    const { data: allPayments } = await supabase
      .from('payments')
      .select('amount, paid_at, credit_id')

    // ── Customer count ──
    const { count: custCount } = await supabase
      .from('customers')
      .select('*', { count: 'exact', head: true })

    // ── All customers (for wishlist) ──
    const { data: allCustomers } = await supabase
      .from('customers')
      .select('id, full_name, phone, wishlist')

    if (!allCredits) { setLoading(false); return }

    const unpaid = allCredits.filter(c => c.status === 'unpaid')
    const paid = allCredits.filter(c => c.status === 'paid')

    // ─ Overview ─
    const totalOwed = unpaid.reduce((s, c) => s + (c.amount - c.amount_paid), 0)
    const overdueCredits = unpaid.filter(c => c.due_date && c.due_date < todayStr)
    const totalEverIssued = allCredits.reduce((s, c) => s + c.amount, 0)
    const totalEverCollected = allCredits.reduce((s, c) => s + c.amount_paid, 0)

    // ─ This month / last month ─
    const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString()
    const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1).toISOString()
    const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0).toISOString()

    const paidThisMonth = (allPayments || [])
      .filter(p => p.paid_at >= thisMonthStart)
      .reduce((s, p) => s + p.amount, 0)

    const paidLastMonth = (allPayments || [])
      .filter(p => p.paid_at >= lastMonthStart && p.paid_at <= lastMonthEnd)
      .reduce((s, p) => s + p.amount, 0)

    setStats({
      totalOwed,
      totalCustomers: custCount || 0,
      overdueCount: overdueCredits.length,
      paidThisMonth,
      paidLastMonth,
      totalEverCollected,
      totalEverIssued,
      creditCount: allCredits.length,
    })

    // ─ Top debtors ─
    const debtorMap = {}
    unpaid.forEach(c => {
      const id = c.customers?.id
      if (!id) return
      const bal = c.amount - c.amount_paid
      if (!debtorMap[id]) debtorMap[id] = { name: c.customers.full_name, phone: c.customers.phone, balance: 0, customerId: id }
      debtorMap[id].balance += bal
    })
    const debtors = Object.values(debtorMap).sort((a, b) => b.balance - a.balance).slice(0, 7)
    setTopDebtors(debtors)

    // ─ Best payers ─
    const payerMap = {}
    allCredits.forEach(c => {
      const id = c.customers?.id
      if (!id || c.amount_paid === 0) return
      if (!payerMap[id]) payerMap[id] = { name: c.customers.full_name, phone: c.customers.phone, totalPaid: 0, customerId: id }
      payerMap[id].totalPaid += c.amount_paid
    })
    const payers = Object.values(payerMap).sort((a, b) => b.totalPaid - a.totalPaid).slice(0, 7)
    setBestPayers(payers)

    // ─ Overdue list ─
    setOverdueList(overdueCredits.slice(0, 10))

    // ─ Monthly trend (last 6 months) ─
    const months = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1)
      const label = d.toLocaleString('default', { month: 'short' })
      const start = new Date(d.getFullYear(), d.getMonth(), 1).toISOString()
      const end = new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString()
      const value = (allPayments || [])
        .filter(p => p.paid_at >= start && p.paid_at <= end)
        .reduce((s, p) => s + p.amount, 0)
      months.push({ label, value })
    }
    setMonthlyTrend(months)

    // ─ Most wanted products from wishlists ─
    const productCount = {}
    ;(allCustomers || []).forEach(c => {
      if (!c.wishlist) return
      c.wishlist.split(',').forEach(item => {
        const key = item.trim().toLowerCase()
        if (!key) return
        productCount[key] = (productCount[key] || 0) + 1
      })
    })
    const products = Object.entries(productCount)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8)
    setTopProducts(products)

    // ─ Payment split ─
    const fullyPaidCount = paid.length
    const partialCount = unpaid.filter(c => c.amount_paid > 0).length
    const total = allCredits.length || 1
    setPaymentSplit({
      fullPct: Math.round((fullyPaidCount / total) * 100),
      partialPct: Math.round((partialCount / total) * 100),
    })

    setLoading(false)
  }

  const monthChange = stats.paidLastMonth > 0
    ? Math.round(((stats.paidThisMonth - stats.paidLastMonth) / stats.paidLastMonth) * 100)
    : null

  const collectionRate = stats.totalEverIssued > 0
    ? Math.round((stats.totalEverCollected / stats.totalEverIssued) * 100)
    : 0

  if (loading) return <div style={styles.loading}>Loading analytics...</div>

  return (
    <div style={styles.container}>

      {/* Header */}
      <div style={styles.header}>
        <Link to="/dashboard" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title}>Analytics</h2>
        <div />
      </div>
      <p style={styles.shopLabel}>{shopName}</p>

      {/* Tabs */}
      <div style={styles.tabs}>
        {[
          { key: 'overview', label: '📊 Overview' },
          { key: 'customers', label: '👥 Customers' },
          { key: 'products', label: '🛍️ Products' },
          { key: 'trends', label: '📈 Trends' },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={tab === t.key ? styles.tabActive : styles.tab}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ═══════════════════════════════════════
          TAB 1 — OVERVIEW
      ═══════════════════════════════════════ */}
      {tab === 'overview' && (
        <>
          {/* Big stats grid */}
          <div style={styles.grid2}>
            <div style={{ ...styles.statCard, gridColumn: 'span 2', backgroundColor: '#1a1a2e' }}>
              <p style={{ ...styles.statLabel, color: '#aaa' }}>Total Outstanding</p>
              <p style={{ ...styles.statValue, color: '#fff', fontSize: '32px' }}>
                ₦{stats.totalOwed.toLocaleString()}
              </p>
              <p style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                across {stats.creditCount} credits · {stats.totalCustomers} customers
              </p>
            </div>

            <div style={{ ...styles.statCard, backgroundColor: stats.overdueCount > 0 ? '#fff0f0' : '#f0fff4' }}>
              <p style={styles.statLabel}>Overdue</p>
              <p style={{ ...styles.statValue, color: stats.overdueCount > 0 ? '#e53e3e' : '#38a169' }}>
                {stats.overdueCount}
              </p>
              <p style={styles.statSub}>credits</p>
            </div>

            <div style={{ ...styles.statCard, backgroundColor: '#f0fff4' }}>
              <p style={styles.statLabel}>Collected (Month)</p>
              <p style={{ ...styles.statValue, color: '#38a169' }}>
                ₦{stats.paidThisMonth.toLocaleString()}
              </p>
              {monthChange !== null && (
                <p style={{ fontSize: '11px', color: monthChange >= 0 ? '#38a169' : '#e53e3e', marginTop: '2px' }}>
                  {monthChange >= 0 ? '▲' : '▼'} {Math.abs(monthChange)}% vs last month
                </p>
              )}
            </div>

            <div style={styles.statCard}>
              <p style={styles.statLabel}>Ever Issued</p>
              <p style={styles.statValue}>₦{stats.totalEverIssued.toLocaleString()}</p>
              <p style={styles.statSub}>all time</p>
            </div>

            <div style={styles.statCard}>
              <p style={styles.statLabel}>Ever Collected</p>
              <p style={{ ...styles.statValue, color: '#38a169' }}>₦{stats.totalEverCollected.toLocaleString()}</p>
              <p style={styles.statSub}>all time</p>
            </div>
          </div>

          {/* Collection rate donut */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Collection Rate</p>
            <div style={styles.donutRow}>
              <DonutRing pct={collectionRate} color="#38a169" size={90} />
              <div style={styles.donutLegend}>
                <p style={styles.donutBig}>
                  ₦{stats.totalEverCollected.toLocaleString()}
                  <span style={{ fontSize: '13px', fontWeight: '400', color: '#888' }}> collected</span>
                </p>
                <p style={styles.donutSub}>of ₦{stats.totalEverIssued.toLocaleString()} issued</p>
                <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
                  <span style={styles.legendDot('38a169')}>Collected</span>
                  <span style={styles.legendDot('e53e3e')}>Outstanding</span>
                </div>
              </div>
            </div>
          </div>

          {/* Payment split */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Credit Status Split</p>
            <div style={styles.splitRow}>
              <div style={styles.splitItem}>
                <DonutRing pct={paymentSplit.fullPct} color="#38a169" size={70} />
                <p style={styles.splitLabel}>Fully Paid</p>
              </div>
              <div style={styles.splitItem}>
                <DonutRing pct={paymentSplit.partialPct} color="#d97706" size={70} />
                <p style={styles.splitLabel}>Partial</p>
              </div>
              <div style={styles.splitItem}>
                <DonutRing pct={Math.max(0, 100 - paymentSplit.fullPct - paymentSplit.partialPct)} color="#e53e3e" size={70} />
                <p style={styles.splitLabel}>Unpaid</p>
              </div>
            </div>
          </div>

          {/* Quick actions */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Quick Actions</p>
            <div style={styles.actionGrid}>
              <Link to="/add-customer" style={styles.actionBtn}>+ Add Customer</Link>
              <Link to="/customers?filter=overdue" style={{ ...styles.actionBtn, backgroundColor: '#e53e3e' }}>⚠️ Overdue</Link>
              <Link to="/broadcast" style={{ ...styles.actionBtn, backgroundColor: '#25D366' }}>📢 Broadcast</Link>
              <Link to="/customers" style={styles.actionBtnOutline}>View All</Link>
            </div>
          </div>
        </>
      )}

      {/* ═══════════════════════════════════════
          TAB 2 — CUSTOMERS
      ═══════════════════════════════════════ */}
      {tab === 'customers' && (
        <>
          {/* Top debtors */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>🏆 Top Debtors</p>
            {topDebtors.length === 0
              ? <p style={styles.empty}>No outstanding debts — great!</p>
              : (() => {
                  const maxBal = topDebtors[0]?.balance || 1
                  return topDebtors.map((d, i) => (
                    <div
                      key={d.customerId}
                      style={styles.rankRow}
                      onClick={() => navigate(`/add-credit?customerId=${d.customerId}&customerName=${encodeURIComponent(d.name)}`)}
                    >
                      <div style={styles.rankNum}>#{i + 1}</div>
                      <div style={{ flex: 1 }}>
                        <div style={styles.rankNameRow}>
                          <p style={styles.rankName}>{d.name}</p>
                          <p style={{ ...styles.rankAmt, color: '#e53e3e' }}>₦{d.balance.toLocaleString()}</p>
                        </div>
                        <HBar pct={Math.round((d.balance / maxBal) * 100)} color="#e53e3e" />
                      </div>
                    </div>
                  ))
                })()
            }
          </div>

          {/* Best payers */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>⭐ Best Payers</p>
            {bestPayers.length === 0
              ? <p style={styles.empty}>No payments recorded yet.</p>
              : (() => {
                  const maxPaid = bestPayers[0]?.totalPaid || 1
                  return bestPayers.map((p, i) => (
                    <div
                      key={p.customerId}
                      style={styles.rankRow}
                      onClick={() => navigate(`/add-credit?customerId=${p.customerId}&customerName=${encodeURIComponent(p.name)}`)}
                    >
                      <div style={{ ...styles.rankNum, backgroundColor: '#f0fff4', color: '#38a169' }}>#{i + 1}</div>
                      <div style={{ flex: 1 }}>
                        <div style={styles.rankNameRow}>
                          <p style={styles.rankName}>{p.name}</p>
                          <p style={{ ...styles.rankAmt, color: '#38a169' }}>₦{p.totalPaid.toLocaleString()}</p>
                        </div>
                        <HBar pct={Math.round((p.totalPaid / maxPaid) * 100)} color="#38a169" />
                      </div>
                    </div>
                  ))
                })()
            }
          </div>

          {/* Overdue customers */}
          {overdueList.length > 0 && (
            <div style={styles.section}>
              <p style={styles.sectionTitle}>⚠️ Overdue Credits</p>
              {overdueList.map(c => {
                const daysLate = Math.ceil((new Date() - new Date(c.due_date)) / (1000 * 60 * 60 * 24))
                return (
                  <div
                    key={c.id}
                    style={{ ...styles.rankRow, borderLeft: '3px solid #e53e3e', paddingLeft: '12px', cursor: 'pointer' }}
                    onClick={() => navigate(`/add-credit?customerId=${c.customer_id}&customerName=${encodeURIComponent(c.customers?.full_name)}`)}
                  >
                    <div style={{ flex: 1 }}>
                      <p style={styles.rankName}>{c.customers?.full_name}</p>
                      <p style={{ fontSize: '12px', color: '#e53e3e' }}>{daysLate} day{daysLate !== 1 ? 's' : ''} overdue</p>
                    </div>
                    <p style={{ ...styles.rankAmt, color: '#e53e3e' }}>
                      ₦{(c.amount - c.amount_paid).toLocaleString()}
                    </p>
                  </div>
                )
              })}
            </div>
          )}
        </>
      )}

      {/* ═══════════════════════════════════════
          TAB 3 — PRODUCTS (WISHLIST INSIGHTS)
      ═══════════════════════════════════════ */}
      {tab === 'products' && (
        <>
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Most Wanted Products</p>
            <p style={styles.hint}>Based on customer wishlists — stock these first</p>
            {topProducts.length === 0 ? (
              <p style={styles.empty}>No wishlist data yet. Add wishlists when creating customers.</p>
            ) : (() => {
              const maxCount = topProducts[0]?.count || 1
              return topProducts.map((p, i) => (
                <div key={p.name} style={styles.productRow}>
                  <div style={styles.productRank}>{i + 1}</div>
                  <div style={{ flex: 1 }}>
                    <div style={styles.rankNameRow}>
                      <p style={{ ...styles.rankName, textTransform: 'capitalize' }}>{p.name}</p>
                      <p style={styles.productCount}>{p.count} customer{p.count > 1 ? 's' : ''}</p>
                    </div>
                    <HBar pct={Math.round((p.count / maxCount) * 100)} color="#4a90e2" />
                  </div>
                </div>
              ))
            })()}
          </div>

          <div style={styles.section}>
            <p style={styles.sectionTitle}>💡 Broadcast Opportunity</p>
            <p style={styles.hint}>
              When you restock any of these items, use the Broadcast page to instantly notify every customer who wants it.
            </p>
            <Link to="/broadcast" style={{ ...styles.fullBtn, backgroundColor: '#25D366', textDecoration: 'none', display: 'block', textAlign: 'center' }}>
              📢 Go to Broadcast
            </Link>
          </div>
        </>
      )}

      {/* ═══════════════════════════════════════
          TAB 4 — TRENDS
      ═══════════════════════════════════════ */}
      {tab === 'trends' && (
        <>
          {/* Monthly collections bar chart */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Monthly Collections</p>
            <p style={styles.hint}>How much you collected each month (last 6 months)</p>
            <BarChart data={monthlyTrend} color="#38a169" valuePrefix="₦" />
            <div style={styles.chartLegendRow}>
              {monthlyTrend.map((m, i) => (
                <div key={i} style={styles.chartLegendItem}>
                  <p style={styles.chartLegendAmt}>
                    {m.value > 0 ? `₦${(m.value / 1000).toFixed(0)}k` : '—'}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* This month vs last month */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>Month Comparison</p>
            <div style={styles.compareGrid}>
              <div style={styles.compareCard}>
                <p style={styles.comparePeriod}>Last Month</p>
                <p style={styles.compareAmt}>₦{stats.paidLastMonth.toLocaleString()}</p>
              </div>
              <div style={{ ...styles.compareCard, backgroundColor: '#f0fff4', border: '1.5px solid #38a169' }}>
                <p style={{ ...styles.comparePeriod, color: '#38a169' }}>This Month</p>
                <p style={{ ...styles.compareAmt, color: '#38a169' }}>₦{stats.paidThisMonth.toLocaleString()}</p>
              </div>
            </div>
            {monthChange !== null && (
              <div style={{ ...styles.changeBadge, backgroundColor: monthChange >= 0 ? '#f0fff4' : '#fff0f0' }}>
                <p style={{ color: monthChange >= 0 ? '#38a169' : '#e53e3e', fontWeight: '700', fontSize: '15px' }}>
                  {monthChange >= 0 ? '▲' : '▼'} {Math.abs(monthChange)}% {monthChange >= 0 ? 'increase' : 'decrease'} in collections
                </p>
                <p style={{ color: '#888', fontSize: '12px', marginTop: '2px' }}>compared to last month</p>
              </div>
            )}
          </div>

          {/* All time summary */}
          <div style={styles.section}>
            <p style={styles.sectionTitle}>All Time Summary</p>
            <div style={styles.allTimeRow}>
              <div style={styles.allTimeItem}>
                <p style={styles.allTimeLabel}>Credits Issued</p>
                <p style={styles.allTimeValue}>{stats.creditCount}</p>
              </div>
              <div style={styles.allTimeItem}>
                <p style={styles.allTimeLabel}>Total Loaned</p>
                <p style={styles.allTimeValue}>₦{(stats.totalEverIssued / 1000).toFixed(0)}k</p>
              </div>
              <div style={styles.allTimeItem}>
                <p style={styles.allTimeLabel}>Total Recovered</p>
                <p style={{ ...styles.allTimeValue, color: '#38a169' }}>₦{(stats.totalEverCollected / 1000).toFixed(0)}k</p>
              </div>
              <div style={styles.allTimeItem}>
                <p style={styles.allTimeLabel}>Recovery Rate</p>
                <p style={{ ...styles.allTimeValue, color: collectionRate >= 70 ? '#38a169' : '#e53e3e' }}>
                  {collectionRate}%
                </p>
              </div>
            </div>
          </div>
        </>
      )}

    </div>
  )
}

// ── Helpers ──
const legendDot = (hex) => ({
  fontSize: '12px',
  color: '#888',
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
})

const styles = {
  container: { maxWidth: '480px', margin: '0 auto', padding: '20px', minHeight: '100vh', backgroundColor: '#f0f4f8' },
  loading: { display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', fontSize: '16px', color: '#888' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px', paddingTop: '10px' },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },
  shopLabel: { fontSize: '13px', color: '#888', textAlign: 'center', marginBottom: '16px' },

  // Tabs
  tabs: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px', marginBottom: '20px' },
  tab: { padding: '8px 2px', backgroundColor: '#fff', color: '#888', border: '1.5px solid #e0e0e0', borderRadius: '10px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', textAlign: 'center' },
  tabActive: { padding: '8px 2px', backgroundColor: '#1a1a2e', color: '#fff', border: '1.5px solid #1a1a2e', borderRadius: '10px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', textAlign: 'center' },

  // Stats
  grid2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' },
  statCard: { backgroundColor: '#fff', borderRadius: '14px', padding: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  statLabel: { fontSize: '11px', color: '#888', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' },
  statValue: { fontSize: '22px', fontWeight: '800', color: '#1a1a2e' },
  statSub: { fontSize: '11px', color: '#aaa', marginTop: '2px' },

  section: { backgroundColor: '#fff', borderRadius: '16px', padding: '20px', marginBottom: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  sectionTitle: { fontSize: '13px', fontWeight: '700', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '14px' },
  hint: { fontSize: '12px', color: '#aaa', marginBottom: '14px', lineHeight: '1.5' },
  empty: { color: '#aaa', fontSize: '14px', textAlign: 'center', padding: '10px 0' },

  // Donut
  donutRow: { display: 'flex', alignItems: 'center', gap: '20px' },
  donutLegend: { flex: 1 },
  donutBig: { fontSize: '18px', fontWeight: '800', color: '#1a1a2e' },
  donutSub: { fontSize: '12px', color: '#888', marginTop: '2px' },
  legendDot: (hex) => ({ fontSize: '12px', color: '#' + hex, fontWeight: '600' }),

  // Split
  splitRow: { display: 'flex', justifyContent: 'space-around', alignItems: 'center' },
  splitItem: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' },
  splitLabel: { fontSize: '12px', color: '#888', fontWeight: '600' },

  // Rankings
  rankRow: { display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 0', borderBottom: '1px solid #f0f0f0', cursor: 'pointer' },
  rankNum: { width: '28px', height: '28px', borderRadius: '50%', backgroundColor: '#f0f4f8', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '700', color: '#1a1a2e', flexShrink: 0 },
  rankNameRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '5px' },
  rankName: { fontWeight: '600', fontSize: '14px', color: '#1a1a2e' },
  rankAmt: { fontWeight: '700', fontSize: '14px' },

  // Products
  productRow: { display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 0', borderBottom: '1px solid #f0f0f0' },
  productRank: { width: '24px', height: '24px', borderRadius: '50%', backgroundColor: '#eef3ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '700', color: '#4a90e2', flexShrink: 0 },
  productCount: { fontSize: '12px', color: '#4a90e2', fontWeight: '600' },

  // Chart
  chartLegendRow: { display: 'flex', gap: '6px', marginTop: '6px' },
  chartLegendItem: { flex: 1, textAlign: 'center' },
  chartLegendAmt: { fontSize: '10px', color: '#888' },

  // Month compare
  compareGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' },
  compareCard: { backgroundColor: '#f0f4f8', borderRadius: '12px', padding: '16px', textAlign: 'center' },
  comparePeriod: { fontSize: '12px', color: '#888', marginBottom: '6px' },
  compareAmt: { fontSize: '18px', fontWeight: '800', color: '#1a1a2e' },
  changeBadge: { borderRadius: '12px', padding: '14px', textAlign: 'center' },

  // All time
  allTimeRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' },
  allTimeItem: { textAlign: 'center' },
  allTimeLabel: { fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' },
  allTimeValue: { fontSize: '20px', fontWeight: '800', color: '#1a1a2e' },

  // Actions
  actionGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' },
  actionBtn: { padding: '12px', backgroundColor: '#1a1a2e', color: '#fff', borderRadius: '10px', textAlign: 'center', textDecoration: 'none', fontWeight: '600', fontSize: '13px' },
  actionBtnOutline: { padding: '12px', backgroundColor: '#fff', color: '#1a1a2e', border: '1.5px solid #1a1a2e', borderRadius: '10px', textAlign: 'center', textDecoration: 'none', fontWeight: '600', fontSize: '13px' },
  fullBtn: { width: '100%', padding: '14px', backgroundColor: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '10px', fontSize: '15px', fontWeight: '600', cursor: 'pointer', boxSizing: 'border-box' },
}

export default Analytics
