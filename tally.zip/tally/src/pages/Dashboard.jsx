import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, Link } from 'react-router-dom'
import PaymentReminders from '../components/PaymentReminders'

function Dashboard() {
  const [totalOwed, setTotalOwed] = useState(0)
  const [overdueCount, setOverdueCount] = useState(0)
  const [customerCount, setCustomerCount] = useState(0)
  const [recentCustomers, setRecentCustomers] = useState([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    getUser()
    fetchStats()
  }, [])

  const getUser = async () => {
    const { data } = await supabase.auth.getUser()
    setUser(data.user)
  }

  const fetchStats = async () => {
    const today = new Date().toISOString().split('T')[0]

    const { data: credits } = await supabase
      .from('credits')
      .select('*, customers(id, full_name)')
      .eq('status', 'unpaid')

    if (credits) {
      const total = credits.reduce((sum, c) => sum + (c.amount - c.amount_paid), 0)
      setTotalOwed(total)

      const overdueIds = new Set(
        credits
          .filter(c => c.due_date && c.due_date < today)
          .map(c => c.customer_id)
      )
      setOverdueCount(overdueIds.size)

      // Build per-customer balance map
      const customerMap = {}
      credits.forEach(c => {
        const id = c.customer_id
        const name = c.customers?.full_name || 'Unknown'
        const balance = c.amount - c.amount_paid
        const isOverdue = c.due_date && c.due_date < today

        if (!customerMap[id]) {
          customerMap[id] = {
            customerId: id,
            name,
            totalBalance: 0,
            isOverdue: false,
            latestDue: c.due_date,
          }
        }
        customerMap[id].totalBalance += balance
        if (isOverdue) customerMap[id].isOverdue = true
        if (c.due_date && (!customerMap[id].latestDue || c.due_date < customerMap[id].latestDue)) {
          customerMap[id].latestDue = c.due_date
        }
      })

      const sorted = Object.values(customerMap)
        .sort((a, b) => b.totalBalance - a.totalBalance)
        .slice(0, 5)

      setRecentCustomers(sorted)
    }

    const { count } = await supabase
      .from('customers')
      .select('*', { count: 'exact', head: true })

    setCustomerCount(count || 0)
    setLoading(false)
  }

  const handleLogout = async () => {
    // Clear pro cache on logout
    try {
      localStorage.removeItem('tally_pro_expiry')
      localStorage.removeItem('tally_pro_plan')
      localStorage.removeItem('tally_pro_ref')
    } catch (e) {}
    await supabase.auth.signOut()
    navigate('/')
  }

  if (loading) return <div style={styles.loading}>Loading...</div>

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.logo}>Tally</h1>
        <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
      </div>

      <div style={styles.welcome}>
        <p style={styles.welcomeText}>Welcome back 👋</p>
        <p style={styles.shopName}>
          {user?.user_metadata?.shop_name || 'Your Shop'}
        </p>
      </div>

      {/* Stats */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <p style={styles.statLabel}>Total Owed</p>
          <p style={styles.statValue}>₦{totalOwed.toLocaleString()}</p>
        </div>

        <div
          style={{
            ...styles.statCard,
            backgroundColor: overdueCount > 0 ? '#fff0f0' : '#f0fff4',
            cursor: overdueCount > 0 ? 'pointer' : 'default',
          }}
          onClick={() => overdueCount > 0 && navigate('/customers?filter=overdue')}
        >
          <p style={styles.statLabel}>Overdue</p>
          <p style={{ ...styles.statValue, color: overdueCount > 0 ? '#e53e3e' : '#38a169' }}>
            {overdueCount} {overdueCount === 1 ? 'customer' : 'customers'}
          </p>
        </div>

        <div style={styles.statCard}>
          <p style={styles.statLabel}>Customers</p>
          <p style={styles.statValue}>{customerCount}</p>
        </div>
      </div>

      {/* Primary actions */}
      <div style={styles.actions}>
        <Link to="/add-customer" style={styles.actionBtn}>+ Add Customer</Link>
        <Link to="/customers" style={styles.actionBtnOutline}>View All</Link>
      </div>

      {/* Secondary actions */}
      <div style={styles.secondaryActions}>
        <Link to="/analytics" style={styles.secondaryBtn}>📊 Analytics</Link>
        <Link
          to="/expenses"
          style={{ ...styles.secondaryBtn, borderColor: '#e53e3e', color: '#e53e3e' }}
        >
          💸 Expenses
        </Link>
        <Link
          to="/broadcast"
          style={{ ...styles.secondaryBtn, borderColor: '#25D366', color: '#25D366' }}
        >
          📢 Broadcast
        </Link>
      </div>

      {/* ⏰ Auto Payment Reminders — Pro only, shows if credits due in 3 days */}
      <PaymentReminders />

      {/* Customers with balance */}
      <div style={styles.section}>
        <h2 style={styles.sectionTitle}>Customers with Balance</h2>
        {recentCustomers.length === 0 ? (
          <div style={styles.empty}>
            <p>No outstanding credits. Add a customer to get started!</p>
          </div>
        ) : (
          recentCustomers.map(c => (
            <div
              key={c.customerId}
              style={styles.creditCard}
              onClick={() =>
                navigate(
                  `/add-credit?customerId=${c.customerId}&customerName=${encodeURIComponent(c.name)}`
                )
              }
            >
              <div style={styles.avatar}>
                {c.name.charAt(0).toUpperCase()}
              </div>
              <div style={{ flex: 1 }}>
                <p style={styles.creditName}>{c.name}</p>
                <p style={{
                  ...styles.creditDate,
                  color: c.isOverdue ? '#e53e3e' : '#38a169',
                }}>
                  {c.isOverdue
                    ? `⚠️ Overdue — due ${c.latestDue}`
                    : c.latestDue
                    ? `Due: ${c.latestDue}`
                    : 'No due date'}
                </p>
              </div>
              <div style={styles.creditAmount}>
                <p style={styles.amountText}>₦{c.totalBalance.toLocaleString()}</p>
                <p style={styles.amountLabel}>balance</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

const styles = {
  container: {
    maxWidth: '480px',
    margin: '0 auto',
    padding: '20px',
    minHeight: '100vh',
    backgroundColor: '#f0f4f8',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '24px',
    paddingTop: '10px',
  },
  logo: { fontSize: '24px', fontWeight: '800', color: '#1a1a2e' },
  logoutBtn: {
    padding: '8px 16px',
    backgroundColor: 'transparent',
    border: '1.5px solid #1a1a2e',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '600',
  },
  welcome: { marginBottom: '24px' },
  welcomeText: { fontSize: '14px', color: '#888' },
  shopName: { fontSize: '22px', fontWeight: '700', color: '#1a1a2e' },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '12px',
    marginBottom: '20px',
  },
  statCard: {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '16px 12px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  statLabel: {
    fontSize: '11px',
    color: '#888',
    marginBottom: '6px',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  statValue: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },
  actions: { display: 'flex', gap: '12px', marginBottom: '12px' },
  actionBtn: {
    flex: 1, padding: '14px', backgroundColor: '#1a1a2e', color: '#ffffff',
    borderRadius: '10px', textAlign: 'center', textDecoration: 'none',
    fontWeight: '600', fontSize: '14px',
  },
  actionBtnOutline: {
    flex: 1, padding: '14px', backgroundColor: '#ffffff', color: '#1a1a2e',
    borderRadius: '10px', textAlign: 'center', textDecoration: 'none',
    fontWeight: '600', fontSize: '14px', border: '1.5px solid #1a1a2e',
  },
  secondaryActions: {
    display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '10px', marginBottom: '20px',
  },
  secondaryBtn: {
    padding: '12px', backgroundColor: '#ffffff', color: '#1a1a2e',
    borderRadius: '10px', textAlign: 'center', textDecoration: 'none',
    fontWeight: '600', fontSize: '13px', border: '1.5px solid #1a1a2e',
  },
  section: {
    backgroundColor: '#ffffff', borderRadius: '16px',
    padding: '20px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  sectionTitle: {
    fontSize: '16px', fontWeight: '700', color: '#1a1a2e', marginBottom: '16px',
  },
  empty: { textAlign: 'center', color: '#888', padding: '20px 0', fontSize: '14px' },
  creditCard: {
    display: 'flex', alignItems: 'center', gap: '12px',
    padding: '14px 0', borderBottom: '1px solid #f0f0f0', cursor: 'pointer',
  },
  avatar: {
    width: '40px', height: '40px', borderRadius: '50%',
    backgroundColor: '#1a1a2e', color: '#ffffff',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: '16px', fontWeight: '700', flexShrink: 0,
  },
  creditName: { fontWeight: '600', fontSize: '15px', color: '#1a1a2e', marginBottom: '3px' },
  creditDate: { fontSize: '12px' },
  creditAmount: { textAlign: 'right', flexShrink: 0 },
  amountText: { fontWeight: '700', fontSize: '16px', color: '#1a1a2e' },
  amountLabel: { fontSize: '11px', color: '#888' },
  loading: {
    display: 'flex', justifyContent: 'center', alignItems: 'center',
    minHeight: '100vh', fontSize: '16px', color: '#888',
  },
}

export default Dashboard
