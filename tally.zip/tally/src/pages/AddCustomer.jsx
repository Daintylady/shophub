import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useNavigate, Link } from 'react-router-dom'

function AddCustomer() {
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [guarantorName, setGuarantorName] = useState('')
  const [guarantorPhone, setGuarantorPhone] = useState('')
  const [notes, setNotes] = useState('')
  const [wishlist, setWishlist] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const { data: { user } } = await supabase.auth.getUser()

    // Check for duplicate name in this shop
    const { data: existing } = await supabase
      .from('customers')
      .select('id')
      .eq('shop_id', user.id)
      .ilike('full_name', fullName.trim())

    if (existing && existing.length > 0) {
      setError(`A customer named "${fullName}" already exists. Use a different name like "${fullName} 2".`)
      setLoading(false)
      return
    }

    const { error } = await supabase.from('customers').insert({
      full_name: fullName.trim(),
      phone,
      address,
      guarantor_name: guarantorName,
      guarantor_phone: guarantorPhone,
      notes,
      wishlist,
      shop_id: user.id,
    })

    if (error) {
      setError(error.message)
      setLoading(false)
    } else {
      navigate('/customers')
    }
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <Link to="/customers" style={styles.backBtn}>← Back</Link>
        <h2 style={styles.title}>Add Customer</h2>
        <div />
      </div>

      {error && <div style={styles.error}>{error}</div>}

      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.section}>
          <p style={styles.sectionTitle}>Customer Details</p>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Full Name *</label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Enter customer name"
              style={styles.input}
              required
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Phone Number</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="e.g. 08012345678"
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter address"
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Loves red fabric, prefers cash"
              style={styles.textarea}
              rows={2}
            />
          </div>
        </div>

        <div style={styles.section}>
          <p style={styles.sectionTitle}>🛍️ Wishlist / Needs</p>
          <p style={styles.hint}>What products is this customer looking for? Separate with commas.</p>
          <textarea
            value={wishlist}
            onChange={(e) => setWishlist(e.target.value)}
            placeholder="e.g. red handbag, blue shoes, ankara fabric"
            style={styles.textarea}
            rows={3}
          />
        </div>

        <div style={styles.section}>
          <p style={styles.sectionTitle}>Guarantor Details</p>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Guarantor Name</label>
            <input
              type="text"
              value={guarantorName}
              onChange={(e) => setGuarantorName(e.target.value)}
              placeholder="Who vouches for this customer?"
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Guarantor Phone</label>
            <input
              type="tel"
              value={guarantorPhone}
              onChange={(e) => setGuarantorPhone(e.target.value)}
              placeholder="Guarantor phone number"
              style={styles.input}
            />
          </div>
        </div>

        <button
          type="submit"
          style={loading ? styles.buttonDisabled : styles.button}
          disabled={loading}
        >
          {loading ? 'Saving...' : 'Save Customer'}
        </button>
      </form>
    </div>
  )
}

const styles = {
  container: { maxWidth: '480px', margin: '0 auto', padding: '20px', minHeight: '100vh', backgroundColor: '#f0f4f8' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', paddingTop: '10px' },
  backBtn: { color: '#1a1a2e', textDecoration: 'none', fontWeight: '600', fontSize: '15px' },
  title: { fontSize: '18px', fontWeight: '700', color: '#1a1a2e' },
  form: { display: 'flex', flexDirection: 'column', gap: '16px' },
  section: { backgroundColor: '#ffffff', borderRadius: '16px', padding: '20px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)', display: 'flex', flexDirection: 'column', gap: '14px' },
  sectionTitle: { fontSize: '13px', fontWeight: '700', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px' },
  hint: { fontSize: '12px', color: '#aaa', marginTop: '-8px' },
  inputGroup: { display: 'flex', flexDirection: 'column', gap: '6px' },
  label: { fontSize: '14px', fontWeight: '600', color: '#1a1a2e' },
  input: { padding: '12px 16px', borderRadius: '10px', border: '1.5px solid #e0e0e0', fontSize: '15px', outline: 'none', backgroundColor: '#fff' },
  textarea: { padding: '12px 16px', borderRadius: '10px', border: '1.5px solid #e0e0e0', fontSize: '15px', outline: 'none', resize: 'vertical', backgroundColor: '#fff' },
  button: { padding: '16px', backgroundColor: '#1a1a2e', color: '#ffffff', border: 'none', borderRadius: '12px', fontSize: '16px', fontWeight: '600', cursor: 'pointer', marginTop: '8px' },
  buttonDisabled: { padding: '16px', backgroundColor: '#888', color: '#ffffff', border: 'none', borderRadius: '12px', fontSize: '16px', fontWeight: '600', cursor: 'not-allowed', marginTop: '8px' },
  error: { backgroundColor: '#fff0f0', color: '#e53e3e', padding: '12px', borderRadius: '8px', fontSize: '14px', marginBottom: '16px', textAlign: 'center' },
}

export default AddCustomer
